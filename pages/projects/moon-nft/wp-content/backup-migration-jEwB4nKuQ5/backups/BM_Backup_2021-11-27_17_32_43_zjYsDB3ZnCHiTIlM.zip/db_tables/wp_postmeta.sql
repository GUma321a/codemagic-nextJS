/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_postmeta`; */
/* PRE_TABLE_NAME: `1638034363_wp_postmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1638034363_wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5803 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
2,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
2,
3,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
11,
9,
'_edit_lock',
'1638033883:1'
/* VALUES END */
), (
/* VALUES START */
12,
2,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
13,
2,
'_wp_trash_meta_time',
1637758087
/* VALUES END */
), (
/* VALUES START */
14,
2,
'_wp_desired_post_slug',
'sample-page'
/* VALUES END */
), (
/* VALUES START */
15,
3,
'_wp_trash_meta_status',
'draft'
/* VALUES END */
), (
/* VALUES START */
16,
3,
'_wp_trash_meta_time',
1637758087
/* VALUES END */
), (
/* VALUES START */
17,
3,
'_wp_desired_post_slug',
'privacy-policy'
/* VALUES END */
), (
/* VALUES START */
18,
13,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
19,
13,
'_edit_lock',
'1638033726:1'
/* VALUES END */
), (
/* VALUES START */
20,
31,
'_wp_attached_file',
'2021/11/logo.svg'
/* VALUES END */
), (
/* VALUES START */
21,
31,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:451;s:6:\"height\";i:134;s:4:\"file\";s:17:\"/2021/11/logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
22,
9,
'inline_featured_image',
0
/* VALUES END */
), (
/* VALUES START */
23,
9,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
24,
9,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
25,
9,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
26,
9,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
27,
9,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
28,
9,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
29,
9,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
30,
9,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
31,
9,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
32,
9,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
33,
9,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
34,
9,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
35,
9,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
36,
9,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
37,
9,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
38,
9,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
39,
9,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
40,
9,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
41,
9,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
42,
9,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
43,
9,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
44,
9,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
45,
9,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
46,
9,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
47,
9,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
48,
9,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
49,
9,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
50,
9,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
51,
9,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
52,
9,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
53,
9,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
54,
9,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
55,
9,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
56,
32,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
57,
32,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
58,
32,
'header__menu-list_header__menu-list-item-1',
''
/* VALUES END */
), (
/* VALUES START */
59,
32,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
60,
32,
'header__menu-list_header__menu-list-link-1',
''
/* VALUES END */
), (
/* VALUES START */
61,
32,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
62,
32,
'header__menu-list_header__menu-list-item-2',
''
/* VALUES END */
), (
/* VALUES START */
63,
32,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
64,
32,
'header__menu-list_header__menu-list-link-2',
''
/* VALUES END */
), (
/* VALUES START */
65,
32,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
66,
32,
'header__menu-list_header__menu-list-item-3',
''
/* VALUES END */
), (
/* VALUES START */
67,
32,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
68,
32,
'header__menu-list_header__menu-list-link-3',
''
/* VALUES END */
), (
/* VALUES START */
69,
32,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
70,
32,
'header__menu-list_header__menu-list-item-4',
''
/* VALUES END */
), (
/* VALUES START */
71,
32,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
72,
32,
'header__menu-list_header__menu-list-link-4',
''
/* VALUES END */
), (
/* VALUES START */
73,
32,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
74,
32,
'header__menu-list_header__menu-list-item-5',
''
/* VALUES END */
), (
/* VALUES START */
75,
32,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
76,
32,
'header__menu-list_header__menu-list-link-5',
''
/* VALUES END */
), (
/* VALUES START */
77,
32,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
78,
32,
'header__menu-list_header__menu-list-item-6',
''
/* VALUES END */
), (
/* VALUES START */
79,
32,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
80,
32,
'header__menu-list_header__menu-list-link-6',
''
/* VALUES END */
), (
/* VALUES START */
81,
32,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
82,
32,
'header__menu-list_header__menu-list-item-7',
''
/* VALUES END */
), (
/* VALUES START */
83,
32,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
84,
32,
'header__menu-list_header__menu-list-link-7',
''
/* VALUES END */
), (
/* VALUES START */
85,
32,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
86,
32,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
87,
32,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
88,
40,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
89,
40,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
90,
40,
'header__menu-list_header__menu-list-item-1',
''
/* VALUES END */
), (
/* VALUES START */
91,
40,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
92,
40,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
93,
40,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
94,
40,
'header__menu-list_header__menu-list-item-2',
''
/* VALUES END */
), (
/* VALUES START */
95,
40,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
96,
40,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
97,
40,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
98,
40,
'header__menu-list_header__menu-list-item-3',
''
/* VALUES END */
), (
/* VALUES START */
99,
40,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
100,
40,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
101,
40,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
102,
40,
'header__menu-list_header__menu-list-item-4',
''
/* VALUES END */
), (
/* VALUES START */
103,
40,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
104,
40,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
105,
40,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
106,
40,
'header__menu-list_header__menu-list-item-5',
''
/* VALUES END */
), (
/* VALUES START */
107,
40,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
108,
40,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
109,
40,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
110,
40,
'header__menu-list_header__menu-list-item-6',
''
/* VALUES END */
), (
/* VALUES START */
111,
40,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
112,
40,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
113,
40,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
114,
40,
'header__menu-list_header__menu-list-item-7',
''
/* VALUES END */
), (
/* VALUES START */
115,
40,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
116,
40,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
117,
40,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
118,
40,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
119,
40,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
120,
41,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
121,
41,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
122,
41,
'header__menu-list_header__menu-list-item-1',
''
/* VALUES END */
), (
/* VALUES START */
123,
41,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
124,
41,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
125,
41,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
126,
41,
'header__menu-list_header__menu-list-item-2',
''
/* VALUES END */
), (
/* VALUES START */
127,
41,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
128,
41,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
129,
41,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
130,
41,
'header__menu-list_header__menu-list-item-3',
''
/* VALUES END */
), (
/* VALUES START */
131,
41,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
132,
41,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
133,
41,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
134,
41,
'header__menu-list_header__menu-list-item-4',
''
/* VALUES END */
), (
/* VALUES START */
135,
41,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
136,
41,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
137,
41,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
138,
41,
'header__menu-list_header__menu-list-item-5',
''
/* VALUES END */
), (
/* VALUES START */
139,
41,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
140,
41,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
141,
41,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
142,
41,
'header__menu-list_header__menu-list-item-6',
''
/* VALUES END */
), (
/* VALUES START */
143,
41,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
144,
41,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
145,
41,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
146,
41,
'header__menu-list_header__menu-list-item-7',
''
/* VALUES END */
), (
/* VALUES START */
147,
41,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
148,
41,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
149,
41,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
150,
41,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
151,
41,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
152,
9,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
153,
9,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
154,
9,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
155,
9,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
156,
9,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
157,
9,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
158,
9,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
159,
9,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
160,
9,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
161,
9,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
162,
9,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
163,
9,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
164,
9,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
165,
9,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
166,
42,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
167,
42,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
168,
42,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
169,
42,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
170,
42,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
171,
42,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
172,
42,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
173,
42,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
174,
42,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
175,
42,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
176,
42,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
177,
42,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
178,
42,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
179,
42,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
180,
42,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
181,
42,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
182,
42,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
183,
42,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
184,
42,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
185,
42,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
186,
42,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
187,
42,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
188,
42,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
189,
42,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
190,
42,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
191,
42,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
192,
42,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
193,
42,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
194,
42,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
195,
42,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
196,
42,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
197,
42,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
198,
42,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
199,
42,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
200,
42,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
201,
42,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
202,
42,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
203,
42,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
204,
42,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
205,
42,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
206,
42,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
207,
42,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
208,
42,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
209,
42,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
210,
42,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
211,
42,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
212,
9,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
213,
9,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
214,
9,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them.\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
215,
9,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
216,
9,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n<span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
217,
9,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
218,
9,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
219,
9,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
220,
9,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
221,
9,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
222,
9,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
223,
9,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
224,
9,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
225,
9,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
226,
9,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
227,
9,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
228,
52,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
229,
52,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
230,
52,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
231,
52,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
232,
52,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
233,
52,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
234,
52,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
235,
52,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
236,
52,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
237,
52,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
238,
52,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
239,
52,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
240,
52,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
241,
52,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
242,
52,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
243,
52,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
244,
52,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
245,
52,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
246,
52,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
247,
52,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
248,
52,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
249,
52,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
250,
52,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
251,
52,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
252,
52,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
253,
52,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
254,
52,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
255,
52,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
256,
52,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
257,
52,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
258,
52,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
259,
52,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
260,
52,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
261,
52,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
262,
52,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
263,
52,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
264,
52,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
265,
52,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
266,
52,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
267,
52,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
268,
52,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
269,
52,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
270,
52,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
271,
52,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
272,
52,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
273,
52,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
274,
52,
'hero__info-title',
'WE ARE CREATING A BLOCKCHAIN METAVERSE'
/* VALUES END */
), (
/* VALUES START */
275,
52,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
276,
52,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots with unique properties that makes you a co-owner of the Moon metaverse and allows you to: create states, cities, economies, items. Rent out land plots and sell them.\r\nMake a profit as a co-owner oh the game.'
/* VALUES END */
), (
/* VALUES START */
277,
52,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
278,
52,
'hero__box_hero__box-text',
'BUY AN\r\nNFT MOON CERTIFICATE\r\nAND GET A\r\nVIRTUAL PIECE OF LAND\r\nIN THE MOON\r\nMETAVERSE'
/* VALUES END */
), (
/* VALUES START */
279,
52,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
280,
52,
'hero__box_hero__box-inner_hero__box-link-text',
''
/* VALUES END */
), (
/* VALUES START */
281,
52,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
282,
52,
'hero__box_hero__box-inner_hero__box-link',
''
/* VALUES END */
), (
/* VALUES START */
283,
52,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
284,
52,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
285,
52,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
286,
52,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
287,
52,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
288,
52,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
289,
52,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
290,
53,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
291,
53,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
292,
53,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
293,
53,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
294,
53,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
295,
53,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
296,
53,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
297,
53,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
298,
53,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
299,
53,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
300,
53,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
301,
53,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
302,
53,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
303,
53,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
304,
53,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
305,
53,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
306,
53,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
307,
53,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
308,
53,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
309,
53,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
310,
53,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
311,
53,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
312,
53,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
313,
53,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
314,
53,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
315,
53,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
316,
53,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
317,
53,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
318,
53,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
319,
53,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
320,
53,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
321,
53,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
322,
53,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
323,
53,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
324,
53,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
325,
53,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
326,
53,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
327,
53,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
328,
53,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
329,
53,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
330,
53,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
331,
53,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
332,
53,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
333,
53,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
334,
53,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
335,
53,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
336,
53,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
337,
53,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
338,
53,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
339,
53,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
340,
53,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
341,
53,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
342,
53,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
343,
53,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
344,
53,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
345,
53,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
346,
53,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
347,
53,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
348,
53,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
349,
53,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
350,
53,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
351,
53,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
352,
54,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
353,
54,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
354,
54,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
355,
54,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
356,
54,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
357,
54,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
358,
54,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
359,
54,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
360,
54,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
361,
54,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
362,
54,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
363,
54,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
364,
54,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
365,
54,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
366,
54,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
367,
54,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
368,
54,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
369,
54,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
370,
54,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
371,
54,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
372,
54,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
373,
54,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
374,
54,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
375,
54,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
376,
54,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
377,
54,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
378,
54,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
379,
54,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
380,
54,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
381,
54,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
382,
54,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
383,
54,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
384,
54,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
385,
54,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
386,
54,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
387,
54,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
388,
54,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
389,
54,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
390,
54,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
391,
54,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
392,
54,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
393,
54,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
394,
54,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
395,
54,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
396,
54,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
397,
54,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
398,
54,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
399,
54,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
400,
54,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
401,
54,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
402,
54,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
403,
54,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
404,
54,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
405,
54,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
406,
54,
'hero__box_hero__box-inner_hero__box-link',
'https://gumaink.site/projects/moon-nft/wp-admin/post.php?post=9&action=edit'
/* VALUES END */
), (
/* VALUES START */
407,
54,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
408,
54,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
409,
54,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
410,
54,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
411,
54,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
412,
54,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
413,
54,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
414,
55,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
415,
55,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
416,
55,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
417,
55,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
418,
55,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
419,
55,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
420,
55,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
421,
55,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
422,
55,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
423,
55,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
424,
55,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
425,
55,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
426,
55,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
427,
55,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
428,
55,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
429,
55,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
430,
55,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
431,
55,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
432,
55,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
433,
55,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
434,
55,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
435,
55,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
436,
55,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
437,
55,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
438,
55,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
439,
55,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
440,
55,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
441,
55,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
442,
55,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
443,
55,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
444,
55,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
445,
55,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
446,
55,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
447,
55,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
448,
55,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
449,
55,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
450,
55,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
451,
55,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
452,
55,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
453,
55,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
454,
55,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
455,
55,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
456,
55,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
457,
55,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
458,
55,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
459,
55,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
460,
55,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
461,
55,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
462,
55,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
463,
55,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
464,
55,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
465,
55,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
466,
55,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
467,
55,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
468,
55,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
469,
55,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
470,
55,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
471,
55,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
472,
55,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
473,
55,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
474,
55,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
475,
55,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
476,
57,
'_wp_attached_file',
'2021/11/moon-decor.svg'
/* VALUES END */
), (
/* VALUES START */
477,
57,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:129;s:6:\"height\";i:129;s:4:\"file\";s:23:\"/2021/11/moon-decor.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:14:\"moon-decor.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:14:\"moon-decor.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:14:\"moon-decor.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:14:\"moon-decor.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:14:\"moon-decor.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:14:\"moon-decor.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
478,
9,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
479,
9,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
480,
58,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
481,
58,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
482,
58,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
483,
58,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
484,
58,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
485,
58,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
486,
58,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
487,
58,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
488,
58,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
489,
58,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
490,
58,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
491,
58,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
492,
58,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
493,
58,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
494,
58,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
495,
58,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
496,
58,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
497,
58,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
498,
58,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
499,
58,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
500,
58,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
501,
58,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
502,
58,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
503,
58,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
504,
58,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
505,
58,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
506,
58,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
507,
58,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
508,
58,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
509,
58,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
510,
58,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
511,
58,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
512,
58,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
513,
58,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
514,
58,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
515,
58,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
516,
58,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
517,
58,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
518,
58,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
519,
58,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
520,
58,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
521,
58,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
522,
58,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
523,
58,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
524,
58,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
525,
58,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
526,
58,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
527,
58,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
528,
58,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
529,
58,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
530,
58,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
531,
58,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
532,
58,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
533,
58,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
534,
58,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
535,
58,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
536,
58,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
537,
58,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
538,
58,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
539,
58,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
540,
58,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
541,
58,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
542,
58,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
543,
58,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
544,
59,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
545,
59,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
546,
59,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
547,
59,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
548,
59,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
549,
59,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
550,
59,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
551,
59,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
552,
59,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
553,
59,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
554,
59,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
555,
59,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
556,
59,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
557,
59,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
558,
59,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
559,
59,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
560,
59,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
561,
59,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
562,
59,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
563,
59,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
564,
59,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
565,
59,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
566,
59,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
567,
59,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
568,
59,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
569,
59,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
570,
59,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
571,
59,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
572,
59,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
573,
59,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
574,
59,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
575,
59,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
576,
59,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
577,
59,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
578,
59,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
579,
59,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
580,
59,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
581,
59,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
582,
59,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
583,
59,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
584,
59,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
585,
59,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
586,
59,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
587,
59,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
588,
59,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
589,
59,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
590,
59,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
591,
59,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
592,
59,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
593,
59,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
594,
59,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
595,
59,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
596,
59,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
597,
59,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
598,
59,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
599,
59,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
600,
59,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
601,
59,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
602,
59,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
603,
59,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
604,
59,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
605,
59,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
606,
59,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
607,
59,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
608,
60,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
609,
60,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
610,
60,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
611,
60,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
612,
60,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
613,
60,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
614,
60,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
615,
60,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
616,
60,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
617,
60,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
618,
60,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
619,
60,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
620,
60,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
621,
60,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
622,
60,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
623,
60,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
624,
60,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
625,
60,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
626,
60,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
627,
60,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
628,
60,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
629,
60,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
630,
60,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
631,
60,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
632,
60,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
633,
60,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
634,
60,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
635,
60,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
636,
60,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
637,
60,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
638,
60,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
639,
60,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
640,
60,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
641,
60,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
642,
60,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
643,
60,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
644,
60,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
645,
60,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
646,
60,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
647,
60,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
648,
60,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
649,
60,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
650,
60,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
651,
60,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
652,
60,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
653,
60,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
654,
60,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
655,
60,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
656,
60,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
657,
60,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
658,
60,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
659,
60,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
660,
60,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
661,
60,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
662,
60,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
663,
60,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
664,
60,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
665,
60,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
666,
60,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
667,
60,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
668,
60,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
669,
60,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
670,
60,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
671,
60,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
672,
61,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
673,
61,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
674,
61,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
675,
61,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
676,
61,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
677,
61,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
678,
61,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
679,
61,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
680,
61,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
681,
61,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
682,
61,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
683,
61,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
684,
61,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
685,
61,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
686,
61,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
687,
61,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
688,
61,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
689,
61,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
690,
61,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
691,
61,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
692,
61,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
693,
61,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
694,
61,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
695,
61,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
696,
61,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
697,
61,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
698,
61,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
699,
61,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
700,
61,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
701,
61,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
702,
61,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
703,
61,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
704,
61,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
705,
61,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
706,
61,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
707,
61,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
708,
61,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
709,
61,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
710,
61,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
711,
61,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
712,
61,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
713,
61,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
714,
61,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
715,
61,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
716,
61,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
717,
61,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
718,
61,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
719,
61,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
720,
61,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
721,
61,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
722,
61,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
723,
61,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
724,
61,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
725,
61,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
726,
61,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
727,
61,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
728,
61,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
729,
61,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
730,
61,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
731,
61,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
732,
61,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
733,
61,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
734,
61,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
735,
61,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
736,
9,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
737,
9,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
738,
9,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
739,
9,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
740,
9,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
741,
9,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
742,
9,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
743,
9,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
744,
9,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
745,
9,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
746,
9,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
747,
9,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
748,
9,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
749,
9,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
750,
9,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
751,
9,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
752,
9,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
753,
9,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
754,
9,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
755,
9,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
756,
9,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
757,
9,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
758,
74,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
759,
74,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
760,
74,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
761,
74,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
762,
74,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
763,
74,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
764,
74,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
765,
74,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
766,
74,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
767,
74,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
768,
74,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
769,
74,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
770,
74,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
771,
74,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
772,
74,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
773,
74,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
774,
74,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
775,
74,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
776,
74,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
777,
74,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
778,
74,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
779,
74,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
780,
74,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
781,
74,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
782,
74,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
783,
74,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
784,
74,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
785,
74,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
786,
74,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
787,
74,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
788,
74,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
789,
74,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
790,
74,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
791,
74,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
792,
74,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
793,
74,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
794,
74,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
795,
74,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
796,
74,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
797,
74,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
798,
74,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
799,
74,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
800,
74,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
801,
74,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
802,
74,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
803,
74,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
804,
74,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
805,
74,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
806,
74,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
807,
74,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
808,
74,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
809,
74,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
810,
74,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
811,
74,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
812,
74,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
813,
74,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
814,
74,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
815,
74,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
816,
74,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
817,
74,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
818,
74,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
819,
74,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
820,
74,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
821,
74,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
822,
74,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
823,
74,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
824,
74,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
825,
74,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
826,
74,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
827,
74,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
828,
74,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
829,
74,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
830,
74,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating \r\na virtual analogue of our moon, which exactly repeats all the characteristics and coordinates. \r\nAnd the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
831,
74,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
832,
74,
'what__wrapper_1_what__item-title',
'                   Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates. And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
833,
74,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
834,
74,
'what__wrapper_1_what__item-text',
12231321
/* VALUES END */
), (
/* VALUES START */
835,
74,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
836,
74,
'what__wrapper',
2
/* VALUES END */
), (
/* VALUES START */
837,
74,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
838,
74,
'faq__wrapper_faq__image',
''
/* VALUES END */
), (
/* VALUES START */
839,
74,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
840,
74,
'faq__wrapper_faq__title',
''
/* VALUES END */
), (
/* VALUES START */
841,
74,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
842,
74,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
843,
74,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
844,
9,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
845,
9,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
846,
9,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
847,
9,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
848,
9,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
849,
9,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
850,
9,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
851,
9,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
852,
9,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
853,
9,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
854,
9,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
855,
9,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
856,
9,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
857,
9,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
858,
9,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
859,
9,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
860,
75,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
861,
75,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
862,
75,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
863,
75,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
864,
75,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
865,
75,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
866,
75,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
867,
75,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
868,
75,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
869,
75,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
870,
75,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
871,
75,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
872,
75,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
873,
75,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
874,
75,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
875,
75,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
876,
75,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
877,
75,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
878,
75,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
879,
75,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
880,
75,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
881,
75,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
882,
75,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
883,
75,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
884,
75,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
885,
75,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
886,
75,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
887,
75,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
888,
75,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
889,
75,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
890,
75,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
891,
75,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
892,
75,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
893,
75,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
894,
75,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
895,
75,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
896,
75,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
897,
75,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
898,
75,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
899,
75,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
900,
75,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
901,
75,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
902,
75,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
903,
75,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
904,
75,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
905,
75,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
906,
75,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
907,
75,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
908,
75,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
909,
75,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
910,
75,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
911,
75,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
912,
75,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
913,
75,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
914,
75,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
915,
75,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
916,
75,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
917,
75,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
918,
75,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
919,
75,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
920,
75,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
921,
75,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
922,
75,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
923,
75,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
924,
75,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
925,
75,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
926,
75,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
927,
75,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
928,
75,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
929,
75,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
930,
75,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
931,
75,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
932,
75,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
933,
75,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
934,
75,
'what__wrapper_1_what__item-title',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates. And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
935,
75,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
936,
75,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
937,
75,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
938,
75,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
939,
75,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
940,
75,
'faq__wrapper_faq__image',
''
/* VALUES END */
), (
/* VALUES START */
941,
75,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
942,
75,
'faq__wrapper_faq__title',
''
/* VALUES END */
), (
/* VALUES START */
943,
75,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
944,
75,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
945,
75,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
946,
75,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
947,
75,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
948,
75,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n- The certificate itself by color level.\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
949,
75,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
950,
75,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
951,
75,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
952,
75,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
953,
75,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
954,
75,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
955,
75,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
956,
75,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
957,
75,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
958,
75,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
959,
75,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
960,
75,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
961,
75,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
962,
76,
'_wp_attached_file',
'2021/11/faq-image.png'
/* VALUES END */
), (
/* VALUES START */
963,
76,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:740;s:6:\"height\";i:588;s:4:\"file\";s:21:\"2021/11/faq-image.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"faq-image-300x238.png\";s:5:\"width\";i:300;s:6:\"height\";i:238;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"faq-image-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
964,
77,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
965,
77,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
966,
77,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
967,
77,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
968,
77,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
969,
77,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
970,
77,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
971,
77,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
972,
77,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
973,
77,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
974,
77,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
975,
77,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
976,
77,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
977,
77,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
978,
77,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
979,
77,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
980,
77,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
981,
77,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
982,
77,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
983,
77,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
984,
77,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
985,
77,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
986,
77,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
987,
77,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
988,
77,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
989,
77,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
990,
77,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
991,
77,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
992,
77,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
993,
77,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
994,
77,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
995,
77,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
996,
77,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
997,
77,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
998,
77,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
999,
77,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1000,
77,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1001,
77,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1002,
77,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1003,
77,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1004,
77,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1005,
77,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1006,
77,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1007,
77,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1008,
77,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1009,
77,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1010,
77,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1011,
77,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1012,
77,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1013,
77,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1014,
77,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1015,
77,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1016,
77,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1017,
77,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1018,
77,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1019,
77,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1020,
77,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1021,
77,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1022,
77,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1023,
77,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1024,
77,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1025,
77,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1026,
77,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1027,
77,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1028,
77,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1029,
77,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1030,
77,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1031,
77,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1032,
77,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
1033,
77,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1034,
77,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1035,
77,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1036,
77,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1037,
77,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1038,
77,
'what__wrapper_1_what__item-title',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates. And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1039,
77,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1040,
77,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1041,
77,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1042,
77,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1043,
77,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1044,
77,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1045,
77,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1046,
77,
'faq__wrapper_faq__title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1047,
77,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1048,
77,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1049,
77,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1050,
77,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1051,
77,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1052,
77,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n- The certificate itself by color level.\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1053,
77,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1054,
77,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1055,
77,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1056,
77,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1057,
77,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1058,
77,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1059,
77,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1060,
77,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1061,
77,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1062,
77,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1063,
77,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1064,
77,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1065,
77,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1066,
9,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
1067,
9,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1068,
78,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1069,
78,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1070,
78,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1071,
78,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1072,
78,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1073,
78,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1074,
78,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1075,
78,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1076,
78,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1077,
78,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1078,
78,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1079,
78,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
1080,
78,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
1081,
78,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
1082,
78,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
1083,
78,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
1084,
78,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
1085,
78,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
1086,
78,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1087,
78,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
1088,
78,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
1089,
78,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
1090,
78,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
1091,
78,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
1092,
78,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
1093,
78,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
1094,
78,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
1095,
78,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
1096,
78,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
1097,
78,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
1098,
78,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
1099,
78,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
1100,
78,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
1101,
78,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
1102,
78,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
1103,
78,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1104,
78,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1105,
78,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1106,
78,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1107,
78,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1108,
78,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1109,
78,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1110,
78,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1111,
78,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1112,
78,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
1113,
78,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1114,
78,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1115,
78,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1116,
78,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1117,
78,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1118,
78,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1119,
78,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1120,
78,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1121,
78,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1122,
78,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1123,
78,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1124,
78,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1125,
78,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1126,
78,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1127,
78,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1128,
78,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1129,
78,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1130,
78,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1131,
78,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1132,
78,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1133,
78,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1134,
78,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1135,
78,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1136,
78,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
1137,
78,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1138,
78,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1139,
78,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1140,
78,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1141,
78,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1142,
78,
'what__wrapper_1_what__item-title',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates. And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1143,
78,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1144,
78,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1145,
78,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1146,
78,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1147,
78,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1148,
78,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1149,
78,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1150,
78,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
1151,
78,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1152,
78,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1153,
78,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1154,
78,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1155,
78,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1156,
78,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n- The certificate itself by color level.\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1157,
78,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1158,
78,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1159,
78,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1160,
78,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1161,
78,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1162,
78,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1163,
78,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1164,
78,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1165,
78,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1166,
78,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1167,
78,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1168,
78,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1169,
78,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1170,
78,
'faq__accordion',
''
/* VALUES END */
), (
/* VALUES START */
1171,
78,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1172,
9,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
1173,
9,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1174,
9,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
1175,
9,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1176,
9,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
1177,
9,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1178,
9,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
1179,
9,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1180,
9,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
1181,
9,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1182,
9,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
1183,
9,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1184,
9,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
1185,
9,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1186,
9,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
1187,
9,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1188,
9,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
1189,
9,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1190,
9,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
1191,
9,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1192,
79,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1193,
79,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1194,
79,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1195,
79,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1196,
79,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1197,
79,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1198,
79,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1199,
79,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1200,
79,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1201,
79,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1202,
79,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1203,
79,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
1204,
79,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
1205,
79,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
1206,
79,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
1207,
79,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
1208,
79,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
1209,
79,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
1210,
79,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1211,
79,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
1212,
79,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
1213,
79,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
1214,
79,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
1215,
79,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
1216,
79,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
1217,
79,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
1218,
79,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
1219,
79,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
1220,
79,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
1221,
79,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
1222,
79,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
1223,
79,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
1224,
79,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
1225,
79,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
1226,
79,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
1227,
79,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1228,
79,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1229,
79,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1230,
79,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1231,
79,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1232,
79,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1233,
79,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1234,
79,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1235,
79,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1236,
79,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
1237,
79,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1238,
79,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1239,
79,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1240,
79,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1241,
79,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1242,
79,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1243,
79,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1244,
79,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1245,
79,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1246,
79,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1247,
79,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1248,
79,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1249,
79,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1250,
79,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1251,
79,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1252,
79,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1253,
79,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1254,
79,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1255,
79,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1256,
79,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1257,
79,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1258,
79,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1259,
79,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1260,
79,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
1261,
79,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1262,
79,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1263,
79,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1264,
79,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1265,
79,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1266,
79,
'what__wrapper_1_what__item-title',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates. And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1267,
79,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1268,
79,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1269,
79,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1270,
79,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1271,
79,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1272,
79,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1273,
79,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1274,
79,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
1275,
79,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1276,
79,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1277,
79,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1278,
79,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1279,
79,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1280,
79,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n- The certificate itself by color level.\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1281,
79,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1282,
79,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1283,
79,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1284,
79,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1285,
79,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1286,
79,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1287,
79,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1288,
79,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1289,
79,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1290,
79,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1291,
79,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1292,
79,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1293,
79,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1294,
79,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
1295,
79,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1296,
79,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
1297,
79,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1298,
79,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
1299,
79,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1300,
79,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
1301,
79,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1302,
79,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
1303,
79,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1304,
79,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
1305,
79,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1306,
79,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
1307,
79,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1308,
79,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
1309,
79,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1310,
79,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
1311,
79,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1312,
79,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
1313,
79,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1314,
79,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
1315,
79,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1316,
80,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1317,
80,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1318,
80,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1319,
80,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1320,
80,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1321,
80,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1322,
80,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1323,
80,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1324,
80,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1325,
80,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1326,
80,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1327,
80,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
1328,
80,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
1329,
80,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
1330,
80,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
1331,
80,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
1332,
80,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
1333,
80,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
1334,
80,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1335,
80,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
1336,
80,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
1337,
80,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
1338,
80,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
1339,
80,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
1340,
80,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
1341,
80,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
1342,
80,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
1343,
80,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
1344,
80,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
1345,
80,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
1346,
80,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
1347,
80,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
1348,
80,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
1349,
80,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
1350,
80,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
1351,
80,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1352,
80,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1353,
80,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1354,
80,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1355,
80,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1356,
80,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1357,
80,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1358,
80,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1359,
80,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1360,
80,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
1361,
80,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1362,
80,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1363,
80,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1364,
80,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1365,
80,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1366,
80,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1367,
80,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1368,
80,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1369,
80,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1370,
80,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1371,
80,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1372,
80,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1373,
80,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1374,
80,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1375,
80,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1376,
80,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1377,
80,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1378,
80,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1379,
80,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1380,
80,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1381,
80,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1382,
80,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1383,
80,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1384,
80,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
1385,
80,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1386,
80,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1387,
80,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1388,
80,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1389,
80,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1390,
80,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
1391,
80,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1392,
80,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1393,
80,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1394,
80,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1395,
80,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1396,
80,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1397,
80,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1398,
80,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
1399,
80,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1400,
80,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1401,
80,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1402,
80,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1403,
80,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1404,
80,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n- The certificate itself by color level.\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1405,
80,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1406,
80,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1407,
80,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1408,
80,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1409,
80,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1410,
80,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1411,
80,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1412,
80,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1413,
80,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1414,
80,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1415,
80,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1416,
80,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1417,
80,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1418,
80,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
1419,
80,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1420,
80,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
1421,
80,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1422,
80,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
1423,
80,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1424,
80,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
1425,
80,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1426,
80,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
1427,
80,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1428,
80,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
1429,
80,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1430,
80,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
1431,
80,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1432,
80,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
1433,
80,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1434,
80,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
1435,
80,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1436,
80,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
1437,
80,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1438,
80,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
1439,
80,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1440,
81,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1441,
81,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1442,
81,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1443,
81,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1444,
81,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1445,
81,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1446,
81,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1447,
81,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1448,
81,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1449,
81,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1450,
81,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1451,
81,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
1452,
81,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
1453,
81,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
1454,
81,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
1455,
81,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
1456,
81,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
1457,
81,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
1458,
81,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1459,
81,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
1460,
81,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
1461,
81,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
1462,
81,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
1463,
81,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
1464,
81,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
1465,
81,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
1466,
81,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
1467,
81,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
1468,
81,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
1469,
81,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
1470,
81,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
1471,
81,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
1472,
81,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
1473,
81,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
1474,
81,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
1475,
81,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1476,
81,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1477,
81,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1478,
81,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1479,
81,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1480,
81,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1481,
81,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1482,
81,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1483,
81,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1484,
81,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
1485,
81,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1486,
81,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1487,
81,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1488,
81,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1489,
81,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1490,
81,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1491,
81,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1492,
81,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1493,
81,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1494,
81,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1495,
81,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1496,
81,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1497,
81,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1498,
81,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1499,
81,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1500,
81,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1501,
81,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1502,
81,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1503,
81,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1504,
81,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1505,
81,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1506,
81,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1507,
81,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1508,
81,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1509,
81,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1510,
81,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1511,
81,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1512,
81,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1513,
81,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1514,
81,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
1515,
81,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1516,
81,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1517,
81,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1518,
81,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1519,
81,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1520,
81,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1521,
81,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1522,
81,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
1523,
81,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1524,
81,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1525,
81,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1526,
81,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1527,
81,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1528,
81,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1529,
81,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1530,
81,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1531,
81,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1532,
81,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1533,
81,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1534,
81,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1535,
81,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1536,
81,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1537,
81,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1538,
81,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1539,
81,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1540,
81,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1541,
81,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1542,
81,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
1543,
81,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1544,
81,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
1545,
81,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1546,
81,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
1547,
81,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1548,
81,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
1549,
81,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1550,
81,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
1551,
81,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1552,
81,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
1553,
81,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1554,
81,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
1555,
81,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1556,
81,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
1557,
81,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1558,
81,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
1559,
81,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1560,
81,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
1561,
81,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1562,
81,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
1563,
81,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1564,
9,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1565,
9,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
1566,
9,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1567,
9,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
1568,
9,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1569,
9,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
1570,
91,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1571,
91,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1572,
91,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1573,
91,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1574,
91,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1575,
91,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1576,
91,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1577,
91,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1578,
91,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1579,
91,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1580,
91,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1581,
91,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
1582,
91,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
1583,
91,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
1584,
91,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
1585,
91,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
1586,
91,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
1587,
91,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
1588,
91,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1589,
91,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
1590,
91,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
1591,
91,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
1592,
91,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
1593,
91,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
1594,
91,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
1595,
91,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
1596,
91,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
1597,
91,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
1598,
91,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
1599,
91,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
1600,
91,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
1601,
91,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
1602,
91,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
1603,
91,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
1604,
91,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
1605,
91,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1606,
91,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1607,
91,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1608,
91,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1609,
91,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1610,
91,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1611,
91,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1612,
91,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1613,
91,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1614,
91,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
1615,
91,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1616,
91,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1617,
91,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1618,
91,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1619,
91,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1620,
91,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1621,
91,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1622,
91,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1623,
91,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1624,
91,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1625,
91,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1626,
91,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1627,
91,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1628,
91,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1629,
91,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1630,
91,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1631,
91,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1632,
91,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1633,
91,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1634,
91,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1635,
91,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1636,
91,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1637,
91,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1638,
91,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
1639,
91,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1640,
91,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1641,
91,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1642,
91,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1643,
91,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1644,
91,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
1645,
91,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1646,
91,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1647,
91,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1648,
91,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1649,
91,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1650,
91,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1651,
91,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1652,
91,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
1653,
91,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1654,
91,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1655,
91,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1656,
91,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1657,
91,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1658,
91,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1659,
91,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1660,
91,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1661,
91,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1662,
91,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1663,
91,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1664,
91,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1665,
91,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1666,
91,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1667,
91,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1668,
91,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1669,
91,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1670,
91,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1671,
91,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1672,
91,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
1673,
91,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1674,
91,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
1675,
91,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1676,
91,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
1677,
91,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1678,
91,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
1679,
91,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1680,
91,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
1681,
91,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1682,
91,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
1683,
91,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1684,
91,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
1685,
91,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1686,
91,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
1687,
91,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1688,
91,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
1689,
91,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1690,
91,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
1691,
91,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1692,
91,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
1693,
91,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1694,
91,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1695,
91,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
1696,
91,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1697,
91,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
1698,
91,
'types__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1699,
91,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
1700,
92,
'_wp_attached_file',
'2021/11/types-image-1.png'
/* VALUES END */
), (
/* VALUES START */
1701,
92,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:818;s:6:\"height\";i:532;s:4:\"file\";s:25:\"2021/11/types-image-1.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"types-image-1-300x195.png\";s:5:\"width\";i:300;s:6:\"height\";i:195;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"types-image-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"types-image-1-768x499.png\";s:5:\"width\";i:768;s:6:\"height\";i:499;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1702,
93,
'_wp_attached_file',
'2021/11/types-image-phone-1.svg'
/* VALUES END */
), (
/* VALUES START */
1703,
93,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:339;s:6:\"height\";i:313;s:4:\"file\";s:32:\"/2021/11/types-image-phone-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:23:\"types-image-phone-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
1704,
94,
'_wp_attached_file',
'2021/11/types-image-2.png'
/* VALUES END */
), (
/* VALUES START */
1705,
94,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:677;s:6:\"height\";i:442;s:4:\"file\";s:25:\"2021/11/types-image-2.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"types-image-2-300x196.png\";s:5:\"width\";i:300;s:6:\"height\";i:196;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"types-image-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1706,
95,
'_wp_attached_file',
'2021/11/types-image-phone-2.svg'
/* VALUES END */
), (
/* VALUES START */
1707,
95,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:339;s:6:\"height\";i:289;s:4:\"file\";s:32:\"/2021/11/types-image-phone-2.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:23:\"types-image-phone-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
1708,
96,
'_wp_attached_file',
'2021/11/types-image-3.png'
/* VALUES END */
), (
/* VALUES START */
1709,
96,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:677;s:6:\"height\";i:442;s:4:\"file\";s:25:\"2021/11/types-image-3.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"types-image-3-300x196.png\";s:5:\"width\";i:300;s:6:\"height\";i:196;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"types-image-3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1710,
97,
'_wp_attached_file',
'2021/11/types-image-phone-3.svg'
/* VALUES END */
), (
/* VALUES START */
1711,
97,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:339;s:6:\"height\";i:295;s:4:\"file\";s:32:\"/2021/11/types-image-phone-3.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:23:\"types-image-phone-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
1712,
98,
'_wp_attached_file',
'2021/11/types-image-4.png'
/* VALUES END */
), (
/* VALUES START */
1713,
98,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:675;s:6:\"height\";i:436;s:4:\"file\";s:25:\"2021/11/types-image-4.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"types-image-4-300x194.png\";s:5:\"width\";i:300;s:6:\"height\";i:194;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"types-image-4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1714,
99,
'_wp_attached_file',
'2021/11/types-image-phone-4.svg'
/* VALUES END */
), (
/* VALUES START */
1715,
99,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:339;s:6:\"height\";i:303;s:4:\"file\";s:32:\"/2021/11/types-image-phone-4.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:23:\"types-image-phone-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
1716,
100,
'_wp_attached_file',
'2021/11/types-image-5.png'
/* VALUES END */
), (
/* VALUES START */
1717,
100,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:675;s:6:\"height\";i:437;s:4:\"file\";s:25:\"2021/11/types-image-5.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"types-image-5-300x194.png\";s:5:\"width\";i:300;s:6:\"height\";i:194;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"types-image-5-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1718,
101,
'_wp_attached_file',
'2021/11/types-image-phone-5.svg'
/* VALUES END */
), (
/* VALUES START */
1719,
101,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:339;s:6:\"height\";i:302;s:4:\"file\";s:32:\"/2021/11/types-image-phone-5.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:23:\"types-image-phone-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
1720,
102,
'_wp_attached_file',
'2021/11/types-image-6.png'
/* VALUES END */
), (
/* VALUES START */
1721,
102,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:678;s:6:\"height\";i:441;s:4:\"file\";s:25:\"2021/11/types-image-6.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"types-image-6-300x195.png\";s:5:\"width\";i:300;s:6:\"height\";i:195;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"types-image-6-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1722,
103,
'_wp_attached_file',
'2021/11/types-image-phone-6.svg'
/* VALUES END */
), (
/* VALUES START */
1723,
103,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:339;s:6:\"height\";i:293;s:4:\"file\";s:32:\"/2021/11/types-image-phone-6.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:23:\"types-image-phone-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:23:\"types-image-phone-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
1724,
9,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
1725,
9,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1726,
9,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
1727,
9,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1728,
9,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
1729,
9,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1730,
9,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1731,
9,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1732,
9,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1733,
9,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1734,
9,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
1735,
9,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1736,
9,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
1737,
9,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1738,
9,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1739,
9,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1740,
9,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1741,
9,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1742,
9,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1743,
9,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1744,
9,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
1745,
9,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1746,
9,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
1747,
9,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1748,
9,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1749,
9,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1750,
9,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1751,
9,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1752,
9,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1753,
9,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1754,
9,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
1755,
9,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1756,
9,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
1757,
9,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1758,
9,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1759,
9,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1760,
9,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1761,
9,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1762,
9,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1763,
9,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1764,
9,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
1765,
9,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1766,
9,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
1767,
9,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1768,
9,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1769,
9,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1770,
9,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1771,
9,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1772,
9,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1773,
9,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1774,
9,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
1775,
9,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1776,
9,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
1777,
9,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1778,
9,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1779,
9,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1780,
9,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1781,
9,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1782,
9,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1783,
9,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1784,
104,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1785,
104,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1786,
104,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1787,
104,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1788,
104,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1789,
104,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1790,
104,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1791,
104,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1792,
104,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1793,
104,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1794,
104,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1795,
104,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
1796,
104,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
1797,
104,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
1798,
104,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
1799,
104,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
1800,
104,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
1801,
104,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
1802,
104,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1803,
104,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
1804,
104,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
1805,
104,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
1806,
104,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
1807,
104,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
1808,
104,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
1809,
104,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
1810,
104,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
1811,
104,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
1812,
104,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
1813,
104,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
1814,
104,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
1815,
104,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
1816,
104,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
1817,
104,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
1818,
104,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
1819,
104,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
1820,
104,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1821,
104,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
1822,
104,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
1823,
104,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
1824,
104,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
1825,
104,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
1826,
104,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
1827,
104,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
1828,
104,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
1829,
104,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
1830,
104,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
1831,
104,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
1832,
104,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
1833,
104,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
1834,
104,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
1835,
104,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
1836,
104,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
1837,
104,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
1838,
104,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1839,
104,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
1840,
104,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
1841,
104,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
1842,
104,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
1843,
104,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
1844,
104,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
1845,
104,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
1846,
104,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
1847,
104,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1848,
104,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
1849,
104,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
1850,
104,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
1851,
104,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
1852,
104,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
1853,
104,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
1854,
104,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1855,
104,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1856,
104,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1857,
104,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1858,
104,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
1859,
104,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1860,
104,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
1861,
104,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1862,
104,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1863,
104,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
1864,
104,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
1865,
104,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
1866,
104,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
1867,
104,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
1868,
104,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1869,
104,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
1870,
104,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
1871,
104,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1872,
104,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
1873,
104,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1874,
104,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1875,
104,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1876,
104,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1877,
104,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1878,
104,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1879,
104,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1880,
104,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1881,
104,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1882,
104,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
1883,
104,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
1884,
104,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
1885,
104,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
1886,
104,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
1887,
104,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
1888,
104,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
1889,
104,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1890,
104,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
1891,
104,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1892,
104,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
1893,
104,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1894,
104,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
1895,
104,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1896,
104,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
1897,
104,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1898,
104,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
1899,
104,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1900,
104,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
1901,
104,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1902,
104,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
1903,
104,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1904,
104,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
1905,
104,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
1906,
104,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
1907,
104,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
1908,
104,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1909,
104,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
1910,
104,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1911,
104,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
1912,
104,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
1913,
104,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
1914,
104,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
1915,
104,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1916,
104,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
1917,
104,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1918,
104,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
1919,
104,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1920,
104,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1921,
104,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1922,
104,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1923,
104,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1924,
104,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
1925,
104,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1926,
104,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
1927,
104,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1928,
104,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1929,
104,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1930,
104,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1931,
104,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1932,
104,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1933,
104,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1934,
104,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
1935,
104,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1936,
104,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
1937,
104,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1938,
104,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1939,
104,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1940,
104,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1941,
104,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1942,
104,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1943,
104,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1944,
104,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
1945,
104,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1946,
104,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
1947,
104,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1948,
104,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1949,
104,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1950,
104,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1951,
104,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1952,
104,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1953,
104,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1954,
104,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
1955,
104,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1956,
104,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
1957,
104,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1958,
104,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1959,
104,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1960,
104,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1961,
104,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1962,
104,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1963,
104,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1964,
104,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
1965,
104,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
1966,
104,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
1967,
104,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
1968,
104,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
1969,
104,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
1970,
104,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
1971,
104,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
1972,
104,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
1973,
104,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
1974,
112,
'_wp_attached_file',
'2021/11/about-image.png'
/* VALUES END */
), (
/* VALUES START */
1975,
112,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:485;s:6:\"height\";i:408;s:4:\"file\";s:23:\"2021/11/about-image.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"about-image-300x252.png\";s:5:\"width\";i:300;s:6:\"height\";i:252;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"about-image-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1976,
9,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
1977,
9,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
1978,
9,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
1979,
9,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
1980,
9,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
1981,
9,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
1982,
9,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
1983,
9,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
1984,
9,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
1985,
9,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
1986,
9,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
1987,
9,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
1988,
113,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
1989,
113,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
1990,
113,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
1991,
113,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
1992,
113,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
1993,
113,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
1994,
113,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
1995,
113,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
1996,
113,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
1997,
113,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
1998,
113,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
1999,
113,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
2000,
113,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
2001,
113,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
2002,
113,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
2003,
113,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
2004,
113,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
2005,
113,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
2006,
113,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2007,
113,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
2008,
113,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
2009,
113,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
2010,
113,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
2011,
113,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
2012,
113,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2013,
113,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
2014,
113,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
2015,
113,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
2016,
113,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
2017,
113,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
2018,
113,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
2019,
113,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
2020,
113,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
2021,
113,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
2022,
113,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2023,
113,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
2024,
113,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2025,
113,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
2026,
113,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
2027,
113,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
2028,
113,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
2029,
113,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
2030,
113,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2031,
113,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
2032,
113,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
2033,
113,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
2034,
113,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
2035,
113,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
2036,
113,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
2037,
113,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
2038,
113,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
2039,
113,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
2040,
113,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2041,
113,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
2042,
113,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2043,
113,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
2044,
113,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
2045,
113,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
2046,
113,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
2047,
113,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
2048,
113,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
2049,
113,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
2050,
113,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
2051,
113,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2052,
113,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
2053,
113,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2054,
113,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
2055,
113,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
2056,
113,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
2057,
113,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
2058,
113,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2059,
113,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2060,
113,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2061,
113,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2062,
113,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
2063,
113,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2064,
113,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
2065,
113,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2066,
113,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2067,
113,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
2068,
113,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
2069,
113,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
2070,
113,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
2071,
113,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
2072,
113,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2073,
113,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
2074,
113,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
2075,
113,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2076,
113,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
2077,
113,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2078,
113,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2079,
113,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2080,
113,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2081,
113,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2082,
113,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2083,
113,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2084,
113,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2085,
113,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2086,
113,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2087,
113,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2088,
113,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2089,
113,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2090,
113,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
2091,
113,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
2092,
113,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
2093,
113,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2094,
113,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
2095,
113,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2096,
113,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
2097,
113,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2098,
113,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
2099,
113,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2100,
113,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
2101,
113,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2102,
113,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
2103,
113,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2104,
113,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
2105,
113,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2106,
113,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
2107,
113,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2108,
113,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
2109,
113,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2110,
113,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
2111,
113,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2112,
113,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2113,
113,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
2114,
113,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2115,
113,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
2116,
113,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2117,
113,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
2118,
113,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
2119,
113,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2120,
113,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
2121,
113,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2122,
113,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
2123,
113,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2124,
113,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2125,
113,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2126,
113,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2127,
113,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2128,
113,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
2129,
113,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2130,
113,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
2131,
113,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2132,
113,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2133,
113,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2134,
113,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2135,
113,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2136,
113,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2137,
113,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2138,
113,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
2139,
113,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2140,
113,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
2141,
113,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2142,
113,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2143,
113,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2144,
113,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2145,
113,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2146,
113,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2147,
113,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2148,
113,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
2149,
113,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2150,
113,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
2151,
113,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2152,
113,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2153,
113,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2154,
113,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2155,
113,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2156,
113,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2157,
113,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2158,
113,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
2159,
113,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2160,
113,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
2161,
113,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2162,
113,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2163,
113,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2164,
113,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2165,
113,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2166,
113,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2167,
113,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2168,
113,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
2169,
113,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2170,
113,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
2171,
113,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2172,
113,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2173,
113,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2174,
113,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2175,
113,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2176,
113,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2177,
113,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2178,
113,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
2179,
113,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
2180,
113,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
2181,
113,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
2182,
113,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
2183,
113,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
2184,
113,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
2185,
113,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
2186,
113,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
2187,
113,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
2188,
113,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2189,
113,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
2190,
120,
'_wp_attached_file',
'2021/11/ownership-image.png'
/* VALUES END */
), (
/* VALUES START */
2191,
120,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:256;s:6:\"height\";i:168;s:4:\"file\";s:27:\"2021/11/ownership-image.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"ownership-image-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
2192,
9,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
2193,
9,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
2194,
9,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2195,
9,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
2196,
9,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
2197,
9,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
2198,
9,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
2199,
9,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
2200,
9,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2201,
9,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
2202,
121,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
2203,
121,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
2204,
121,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
2205,
121,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
2206,
121,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
2207,
121,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
2208,
121,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
2209,
121,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
2210,
121,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2211,
121,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
2212,
121,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2213,
121,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
2214,
121,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
2215,
121,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
2216,
121,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
2217,
121,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
2218,
121,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
2219,
121,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
2220,
121,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2221,
121,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
2222,
121,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
2223,
121,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
2224,
121,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
2225,
121,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
2226,
121,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2227,
121,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
2228,
121,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
2229,
121,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
2230,
121,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
2231,
121,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
2232,
121,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
2233,
121,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
2234,
121,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
2235,
121,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
2236,
121,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2237,
121,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
2238,
121,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2239,
121,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
2240,
121,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
2241,
121,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
2242,
121,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
2243,
121,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
2244,
121,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2245,
121,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
2246,
121,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
2247,
121,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
2248,
121,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
2249,
121,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
2250,
121,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
2251,
121,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
2252,
121,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
2253,
121,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
2254,
121,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2255,
121,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
2256,
121,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2257,
121,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
2258,
121,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
2259,
121,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
2260,
121,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
2261,
121,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
2262,
121,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
2263,
121,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
2264,
121,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
2265,
121,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2266,
121,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
2267,
121,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2268,
121,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
2269,
121,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
2270,
121,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
2271,
121,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
2272,
121,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2273,
121,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2274,
121,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2275,
121,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2276,
121,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
2277,
121,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2278,
121,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
2279,
121,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2280,
121,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2281,
121,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
2282,
121,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
2283,
121,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
2284,
121,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
2285,
121,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
2286,
121,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2287,
121,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
2288,
121,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
2289,
121,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2290,
121,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
2291,
121,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2292,
121,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2293,
121,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2294,
121,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2295,
121,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2296,
121,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2297,
121,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2298,
121,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2299,
121,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2300,
121,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2301,
121,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2302,
121,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2303,
121,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2304,
121,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
2305,
121,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
2306,
121,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
2307,
121,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2308,
121,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
2309,
121,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2310,
121,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
2311,
121,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2312,
121,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
2313,
121,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2314,
121,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
2315,
121,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2316,
121,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
2317,
121,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2318,
121,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
2319,
121,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2320,
121,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
2321,
121,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2322,
121,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
2323,
121,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2324,
121,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
2325,
121,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2326,
121,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2327,
121,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
2328,
121,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2329,
121,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
2330,
121,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2331,
121,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
2332,
121,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
2333,
121,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2334,
121,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
2335,
121,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2336,
121,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
2337,
121,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2338,
121,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2339,
121,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2340,
121,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2341,
121,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2342,
121,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
2343,
121,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2344,
121,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
2345,
121,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2346,
121,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2347,
121,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2348,
121,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2349,
121,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2350,
121,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2351,
121,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2352,
121,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
2353,
121,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2354,
121,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
2355,
121,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2356,
121,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2357,
121,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2358,
121,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2359,
121,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2360,
121,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2361,
121,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2362,
121,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
2363,
121,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2364,
121,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
2365,
121,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2366,
121,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2367,
121,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2368,
121,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2369,
121,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2370,
121,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2371,
121,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2372,
121,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
2373,
121,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2374,
121,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
2375,
121,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2376,
121,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2377,
121,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2378,
121,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2379,
121,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2380,
121,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2381,
121,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2382,
121,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
2383,
121,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2384,
121,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
2385,
121,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2386,
121,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2387,
121,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2388,
121,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2389,
121,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2390,
121,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2391,
121,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2392,
121,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
2393,
121,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
2394,
121,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
2395,
121,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
2396,
121,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
2397,
121,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
2398,
121,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
2399,
121,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
2400,
121,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
2401,
121,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
2402,
121,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2403,
121,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
2404,
121,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
2405,
121,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
2406,
121,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2407,
121,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
2408,
121,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
2409,
121,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
2410,
121,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
2411,
121,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
2412,
121,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2413,
121,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
2414,
128,
'_wp_attached_file',
'2021/11/Frame-1.svg'
/* VALUES END */
), (
/* VALUES START */
2415,
128,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:552;s:6:\"height\";i:445;s:4:\"file\";s:20:\"/2021/11/Frame-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:11:\"Frame-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:11:\"Frame-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:11:\"Frame-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:11:\"Frame-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:11:\"Frame-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:11:\"Frame-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
2416,
9,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
2417,
9,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
2418,
9,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
2419,
9,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
2420,
9,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
2421,
9,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
2422,
9,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
2423,
9,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
2424,
9,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2425,
9,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
2426,
129,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
2427,
129,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
2428,
129,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
2429,
129,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
2430,
129,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
2431,
129,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
2432,
129,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
2433,
129,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
2434,
129,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2435,
129,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
2436,
129,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2437,
129,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
2438,
129,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
2439,
129,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
2440,
129,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
2441,
129,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
2442,
129,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
2443,
129,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
2444,
129,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2445,
129,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
2446,
129,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
2447,
129,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
2448,
129,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
2449,
129,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
2450,
129,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2451,
129,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
2452,
129,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
2453,
129,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
2454,
129,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
2455,
129,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
2456,
129,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
2457,
129,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
2458,
129,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
2459,
129,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
2460,
129,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2461,
129,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
2462,
129,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2463,
129,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
2464,
129,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
2465,
129,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
2466,
129,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
2467,
129,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
2468,
129,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2469,
129,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
2470,
129,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
2471,
129,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
2472,
129,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
2473,
129,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
2474,
129,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
2475,
129,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
2476,
129,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
2477,
129,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
2478,
129,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2479,
129,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
2480,
129,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2481,
129,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
2482,
129,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
2483,
129,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
2484,
129,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
2485,
129,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
2486,
129,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
2487,
129,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
2488,
129,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
2489,
129,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2490,
129,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
2491,
129,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2492,
129,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
2493,
129,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
2494,
129,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
2495,
129,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
2496,
129,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2497,
129,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2498,
129,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2499,
129,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2500,
129,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
2501,
129,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2502,
129,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
2503,
129,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2504,
129,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2505,
129,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
2506,
129,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
2507,
129,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
2508,
129,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
2509,
129,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
2510,
129,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2511,
129,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
2512,
129,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
2513,
129,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2514,
129,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
2515,
129,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2516,
129,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2517,
129,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2518,
129,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2519,
129,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2520,
129,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2521,
129,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2522,
129,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2523,
129,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2524,
129,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2525,
129,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2526,
129,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2527,
129,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2528,
129,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
2529,
129,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
2530,
129,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
2531,
129,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2532,
129,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
2533,
129,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2534,
129,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
2535,
129,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2536,
129,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
2537,
129,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2538,
129,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
2539,
129,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2540,
129,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
2541,
129,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2542,
129,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
2543,
129,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2544,
129,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
2545,
129,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2546,
129,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
2547,
129,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2548,
129,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
2549,
129,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2550,
129,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2551,
129,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
2552,
129,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2553,
129,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
2554,
129,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2555,
129,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
2556,
129,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
2557,
129,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2558,
129,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
2559,
129,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2560,
129,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
2561,
129,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2562,
129,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2563,
129,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2564,
129,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2565,
129,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2566,
129,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
2567,
129,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2568,
129,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
2569,
129,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2570,
129,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2571,
129,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2572,
129,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2573,
129,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2574,
129,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2575,
129,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2576,
129,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
2577,
129,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2578,
129,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
2579,
129,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2580,
129,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2581,
129,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2582,
129,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2583,
129,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2584,
129,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2585,
129,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2586,
129,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
2587,
129,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2588,
129,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
2589,
129,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2590,
129,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2591,
129,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2592,
129,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2593,
129,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2594,
129,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2595,
129,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2596,
129,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
2597,
129,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2598,
129,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
2599,
129,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2600,
129,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2601,
129,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2602,
129,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2603,
129,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2604,
129,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2605,
129,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2606,
129,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
2607,
129,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2608,
129,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
2609,
129,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2610,
129,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2611,
129,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2612,
129,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2613,
129,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2614,
129,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2615,
129,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2616,
129,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
2617,
129,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
2618,
129,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
2619,
129,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
2620,
129,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
2621,
129,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
2622,
129,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
2623,
129,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
2624,
129,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
2625,
129,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
2626,
129,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2627,
129,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
2628,
129,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
2629,
129,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
2630,
129,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2631,
129,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
2632,
129,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
2633,
129,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
2634,
129,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
2635,
129,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
2636,
129,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2637,
129,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
2638,
129,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
2639,
129,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
2640,
129,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
2641,
129,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
2642,
129,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
2643,
129,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
2644,
129,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
2645,
129,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
2646,
129,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2647,
129,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
2648,
9,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
2649,
9,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
2650,
9,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2651,
9,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
2652,
9,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
2653,
9,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
2654,
9,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2655,
9,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
2656,
9,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
2657,
9,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
2658,
9,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2659,
9,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
2660,
9,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
2661,
9,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
2662,
9,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
2663,
9,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
2664,
9,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
2665,
9,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
2666,
9,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
2667,
9,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
2668,
9,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
2669,
9,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
2670,
9,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2671,
9,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
2672,
9,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
2673,
9,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
2674,
144,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
2675,
144,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
2676,
144,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
2677,
144,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
2678,
144,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
2679,
144,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
2680,
144,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
2681,
144,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
2682,
144,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2683,
144,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
2684,
144,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2685,
144,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
2686,
144,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
2687,
144,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
2688,
144,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
2689,
144,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
2690,
144,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
2691,
144,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
2692,
144,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2693,
144,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
2694,
144,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
2695,
144,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
2696,
144,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
2697,
144,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
2698,
144,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2699,
144,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
2700,
144,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
2701,
144,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
2702,
144,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
2703,
144,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
2704,
144,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
2705,
144,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
2706,
144,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
2707,
144,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
2708,
144,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2709,
144,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
2710,
144,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2711,
144,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
2712,
144,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
2713,
144,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
2714,
144,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
2715,
144,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
2716,
144,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2717,
144,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
2718,
144,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
2719,
144,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
2720,
144,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
2721,
144,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
2722,
144,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
2723,
144,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
2724,
144,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
2725,
144,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
2726,
144,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2727,
144,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
2728,
144,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2729,
144,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
2730,
144,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
2731,
144,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
2732,
144,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
2733,
144,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
2734,
144,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
2735,
144,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
2736,
144,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
2737,
144,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2738,
144,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
2739,
144,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
2740,
144,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
2741,
144,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
2742,
144,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
2743,
144,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
2744,
144,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2745,
144,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2746,
144,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2747,
144,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2748,
144,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
2749,
144,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2750,
144,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
2751,
144,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2752,
144,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2753,
144,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
2754,
144,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
2755,
144,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
2756,
144,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
2757,
144,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
2758,
144,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2759,
144,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
2760,
144,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
2761,
144,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2762,
144,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
2763,
144,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2764,
144,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2765,
144,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2766,
144,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2767,
144,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2768,
144,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2769,
144,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2770,
144,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2771,
144,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2772,
144,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
2773,
144,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
2774,
144,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
2775,
144,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
2776,
144,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
2777,
144,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
2778,
144,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
2779,
144,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2780,
144,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
2781,
144,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2782,
144,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
2783,
144,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2784,
144,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
2785,
144,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2786,
144,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
2787,
144,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2788,
144,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
2789,
144,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2790,
144,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
2791,
144,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2792,
144,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
2793,
144,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2794,
144,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
2795,
144,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
2796,
144,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
2797,
144,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
2798,
144,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2799,
144,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
2800,
144,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2801,
144,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
2802,
144,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
2803,
144,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
2804,
144,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
2805,
144,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2806,
144,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
2807,
144,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2808,
144,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
2809,
144,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2810,
144,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2811,
144,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2812,
144,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2813,
144,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2814,
144,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
2815,
144,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2816,
144,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
2817,
144,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2818,
144,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2819,
144,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2820,
144,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2821,
144,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2822,
144,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2823,
144,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2824,
144,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
2825,
144,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2826,
144,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
2827,
144,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2828,
144,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2829,
144,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2830,
144,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2831,
144,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2832,
144,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2833,
144,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2834,
144,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
2835,
144,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2836,
144,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
2837,
144,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2838,
144,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2839,
144,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2840,
144,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2841,
144,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2842,
144,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2843,
144,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2844,
144,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
2845,
144,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2846,
144,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
2847,
144,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2848,
144,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2849,
144,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2850,
144,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2851,
144,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2852,
144,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2853,
144,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2854,
144,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
2855,
144,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
2856,
144,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
2857,
144,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
2858,
144,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
2859,
144,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
2860,
144,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2861,
144,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
2862,
144,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
2863,
144,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
2864,
144,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
2865,
144,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
2866,
144,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
2867,
144,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
2868,
144,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
2869,
144,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
2870,
144,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
2871,
144,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
2872,
144,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
2873,
144,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
2874,
144,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2875,
144,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
2876,
144,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
2877,
144,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
2878,
144,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2879,
144,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
2880,
144,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
2881,
144,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
2882,
144,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
2883,
144,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
2884,
144,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2885,
144,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
2886,
144,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
2887,
144,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
2888,
144,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
2889,
144,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
2890,
144,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
2891,
144,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
2892,
144,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
2893,
144,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
2894,
144,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
2895,
144,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
2896,
144,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
2897,
144,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
2898,
144,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2899,
144,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
2900,
144,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
2901,
144,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
2902,
144,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2903,
144,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
2904,
144,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
2905,
144,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
2906,
144,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2907,
144,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
2908,
144,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
2909,
144,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
2910,
144,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
2911,
144,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
2912,
144,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
2913,
144,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
2914,
144,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
2915,
144,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
2916,
144,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
2917,
144,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
2918,
144,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2919,
144,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
2920,
144,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
2921,
144,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
2922,
9,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
2923,
9,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
2924,
9,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
2925,
9,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
2926,
9,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
2927,
9,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
2928,
9,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
2929,
9,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
2930,
9,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
2931,
9,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
2932,
9,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
2933,
9,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
2934,
9,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
2935,
9,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
2936,
9,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
2937,
9,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
2938,
9,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
2939,
9,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
2940,
154,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
2941,
154,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
2942,
154,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
2943,
154,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
2944,
154,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
2945,
154,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
2946,
154,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
2947,
154,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
2948,
154,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2949,
154,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
2950,
154,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
2951,
154,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
2952,
154,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
2953,
154,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
2954,
154,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
2955,
154,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
2956,
154,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
2957,
154,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
2958,
154,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2959,
154,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
2960,
154,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
2961,
154,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
2962,
154,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
2963,
154,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
2964,
154,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
2965,
154,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
2966,
154,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
2967,
154,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
2968,
154,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
2969,
154,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
2970,
154,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
2971,
154,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
2972,
154,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
2973,
154,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
2974,
154,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
2975,
154,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
2976,
154,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
2977,
154,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
2978,
154,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
2979,
154,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
2980,
154,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
2981,
154,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
2982,
154,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
2983,
154,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
2984,
154,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
2985,
154,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
2986,
154,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
2987,
154,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
2988,
154,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
2989,
154,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
2990,
154,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
2991,
154,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
2992,
154,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
2993,
154,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
2994,
154,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
2995,
154,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
2996,
154,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
2997,
154,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
2998,
154,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
2999,
154,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
3000,
154,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
3001,
154,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
3002,
154,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
3003,
154,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3004,
154,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
3005,
154,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3006,
154,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
3007,
154,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
3008,
154,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
3009,
154,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
3010,
154,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3011,
154,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3012,
154,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3013,
154,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3014,
154,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
3015,
154,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3016,
154,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
3017,
154,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3018,
154,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3019,
154,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
3020,
154,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
3021,
154,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
3022,
154,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
3023,
154,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
3024,
154,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3025,
154,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
3026,
154,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
3027,
154,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3028,
154,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
3029,
154,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3030,
154,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3031,
154,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3032,
154,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3033,
154,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3034,
154,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3035,
154,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3036,
154,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3037,
154,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3038,
154,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3039,
154,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3040,
154,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3041,
154,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3042,
154,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
3043,
154,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
3044,
154,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
3045,
154,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3046,
154,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
3047,
154,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3048,
154,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
3049,
154,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3050,
154,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
3051,
154,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3052,
154,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
3053,
154,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3054,
154,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
3055,
154,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3056,
154,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
3057,
154,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3058,
154,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
3059,
154,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3060,
154,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
3061,
154,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3062,
154,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
3063,
154,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3064,
154,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3065,
154,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
3066,
154,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3067,
154,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
3068,
154,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3069,
154,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
3070,
154,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
3071,
154,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3072,
154,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
3073,
154,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3074,
154,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
3075,
154,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3076,
154,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3077,
154,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3078,
154,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3079,
154,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3080,
154,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
3081,
154,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3082,
154,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
3083,
154,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3084,
154,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3085,
154,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3086,
154,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3087,
154,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3088,
154,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3089,
154,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3090,
154,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
3091,
154,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3092,
154,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
3093,
154,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3094,
154,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3095,
154,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3096,
154,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3097,
154,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3098,
154,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3099,
154,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3100,
154,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
3101,
154,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3102,
154,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
3103,
154,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3104,
154,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3105,
154,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3106,
154,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3107,
154,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3108,
154,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3109,
154,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3110,
154,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
3111,
154,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3112,
154,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
3113,
154,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3114,
154,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3115,
154,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3116,
154,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3117,
154,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3118,
154,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3119,
154,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3120,
154,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
3121,
154,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3122,
154,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
3123,
154,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3124,
154,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3125,
154,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3126,
154,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3127,
154,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3128,
154,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3129,
154,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3130,
154,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
3131,
154,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
3132,
154,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
3133,
154,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
3134,
154,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
3135,
154,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
3136,
154,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
3137,
154,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
3138,
154,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
3139,
154,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
3140,
154,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3141,
154,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
3142,
154,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
3143,
154,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
3144,
154,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3145,
154,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
3146,
154,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
3147,
154,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
3148,
154,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
3149,
154,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
3150,
154,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3151,
154,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
3152,
154,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
3153,
154,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
3154,
154,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
3155,
154,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
3156,
154,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
3157,
154,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
3158,
154,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
3159,
154,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
3160,
154,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3161,
154,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
3162,
154,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
3163,
154,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
3164,
154,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
3165,
154,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
3166,
154,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
3167,
154,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
3168,
154,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3169,
154,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
3170,
154,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
3171,
154,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
3172,
154,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
3173,
154,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
3174,
154,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
3175,
154,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
3176,
154,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
3177,
154,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
3178,
154,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
3179,
154,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
3180,
154,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
3181,
154,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
3182,
154,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
3183,
154,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
3184,
154,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
3185,
154,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
3186,
154,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
3187,
154,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
3188,
154,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
3189,
154,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
3190,
154,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
3191,
154,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
3192,
154,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
3193,
154,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
3194,
154,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
3195,
154,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
3196,
154,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
3197,
154,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
3198,
154,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
3199,
154,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
3200,
154,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
3201,
154,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
3202,
154,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
3203,
154,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
3204,
154,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
3205,
154,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
3206,
9,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
3207,
9,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
3208,
9,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
3209,
9,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
3210,
9,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
3211,
9,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
3212,
9,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
3213,
9,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
3214,
9,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
3215,
9,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
3216,
9,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
3217,
9,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
3218,
9,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
3219,
9,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
3220,
9,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
3221,
9,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
3222,
9,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3223,
9,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
3224,
165,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
3225,
165,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
3226,
165,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
3227,
165,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
3228,
165,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
3229,
165,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
3230,
165,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
3231,
165,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
3232,
165,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3233,
165,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
3234,
165,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3235,
165,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
3236,
165,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
3237,
165,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
3238,
165,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
3239,
165,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
3240,
165,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
3241,
165,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
3242,
165,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3243,
165,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
3244,
165,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
3245,
165,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
3246,
165,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
3247,
165,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
3248,
165,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
3249,
165,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
3250,
165,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
3251,
165,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
3252,
165,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
3253,
165,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
3254,
165,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
3255,
165,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
3256,
165,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
3257,
165,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
3258,
165,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
3259,
165,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
3260,
165,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3261,
165,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
3262,
165,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
3263,
165,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
3264,
165,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
3265,
165,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
3266,
165,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
3267,
165,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
3268,
165,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
3269,
165,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
3270,
165,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
3271,
165,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
3272,
165,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
3273,
165,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
3274,
165,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
3275,
165,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
3276,
165,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3277,
165,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
3278,
165,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3279,
165,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
3280,
165,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
3281,
165,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
3282,
165,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
3283,
165,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
3284,
165,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
3285,
165,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
3286,
165,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
3287,
165,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3288,
165,
'hero__box_hero__box-inner_hero__box-moon',
''
/* VALUES END */
), (
/* VALUES START */
3289,
165,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3290,
165,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
3291,
165,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
3292,
165,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
3293,
165,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
3294,
165,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3295,
165,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3296,
165,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3297,
165,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3298,
165,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
3299,
165,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3300,
165,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
3301,
165,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3302,
165,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3303,
165,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
3304,
165,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
3305,
165,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
3306,
165,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
3307,
165,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
3308,
165,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3309,
165,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
3310,
165,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
3311,
165,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3312,
165,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
3313,
165,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3314,
165,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3315,
165,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3316,
165,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3317,
165,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3318,
165,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3319,
165,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3320,
165,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3321,
165,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3322,
165,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3323,
165,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3324,
165,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3325,
165,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3326,
165,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
3327,
165,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
3328,
165,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
3329,
165,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3330,
165,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
3331,
165,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3332,
165,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
3333,
165,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3334,
165,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
3335,
165,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3336,
165,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
3337,
165,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3338,
165,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
3339,
165,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3340,
165,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
3341,
165,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3342,
165,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
3343,
165,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3344,
165,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
3345,
165,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3346,
165,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
3347,
165,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3348,
165,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3349,
165,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
3350,
165,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3351,
165,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
3352,
165,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3353,
165,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
3354,
165,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
3355,
165,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3356,
165,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
3357,
165,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3358,
165,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
3359,
165,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3360,
165,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3361,
165,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3362,
165,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3363,
165,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3364,
165,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
3365,
165,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3366,
165,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
3367,
165,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3368,
165,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3369,
165,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3370,
165,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3371,
165,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3372,
165,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3373,
165,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3374,
165,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
3375,
165,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3376,
165,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
3377,
165,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3378,
165,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3379,
165,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3380,
165,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3381,
165,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3382,
165,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3383,
165,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3384,
165,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
3385,
165,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3386,
165,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
3387,
165,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3388,
165,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3389,
165,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3390,
165,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3391,
165,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3392,
165,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3393,
165,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3394,
165,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
3395,
165,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3396,
165,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
3397,
165,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3398,
165,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3399,
165,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3400,
165,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3401,
165,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3402,
165,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3403,
165,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3404,
165,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
3405,
165,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3406,
165,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
3407,
165,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3408,
165,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3409,
165,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3410,
165,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3411,
165,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3412,
165,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3413,
165,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3414,
165,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
3415,
165,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
3416,
165,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
3417,
165,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
3418,
165,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
3419,
165,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
3420,
165,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
3421,
165,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
3422,
165,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
3423,
165,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
3424,
165,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3425,
165,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
3426,
165,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
3427,
165,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
3428,
165,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3429,
165,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
3430,
165,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
3431,
165,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
3432,
165,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
3433,
165,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
3434,
165,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3435,
165,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
3436,
165,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
3437,
165,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
3438,
165,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
3439,
165,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
3440,
165,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
3441,
165,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
3442,
165,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
3443,
165,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
3444,
165,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3445,
165,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
3446,
165,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
3447,
165,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
3448,
165,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
3449,
165,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
3450,
165,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
3451,
165,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
3452,
165,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3453,
165,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
3454,
165,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
3455,
165,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
3456,
165,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
3457,
165,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
3458,
165,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
3459,
165,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
3460,
165,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
3461,
165,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
3462,
165,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
3463,
165,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
3464,
165,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
3465,
165,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
3466,
165,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
3467,
165,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
3468,
165,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
3469,
165,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
3470,
165,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
3471,
165,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
3472,
165,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
3473,
165,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
3474,
165,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
3475,
165,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
3476,
165,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
3477,
165,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
3478,
165,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
3479,
165,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
3480,
165,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
3481,
165,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
3482,
165,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
3483,
165,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
3484,
165,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
3485,
165,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
3486,
165,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
3487,
165,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
3488,
165,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
3489,
165,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
3490,
165,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
3491,
165,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
3492,
165,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
3493,
165,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
3494,
165,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
3495,
165,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
3496,
165,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
3497,
165,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
3498,
165,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
3499,
165,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
3500,
165,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
3501,
165,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
3502,
165,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
3503,
165,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
3504,
165,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
3505,
165,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
3506,
165,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3507,
165,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
3508,
166,
'header__logo-link',
31
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
3509,
166,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
3510,
166,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
3511,
166,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
3512,
166,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
3513,
166,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
3514,
166,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
3515,
166,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
3516,
166,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3517,
166,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
3518,
166,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3519,
166,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
3520,
166,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
3521,
166,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
3522,
166,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
3523,
166,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
3524,
166,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
3525,
166,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
3526,
166,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3527,
166,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
3528,
166,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
3529,
166,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
3530,
166,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
3531,
166,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
3532,
166,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
3533,
166,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
3534,
166,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
3535,
166,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
3536,
166,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
3537,
166,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
3538,
166,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
3539,
166,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
3540,
166,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
3541,
166,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
3542,
166,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
3543,
166,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
3544,
166,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3545,
166,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
3546,
166,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
3547,
166,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
3548,
166,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
3549,
166,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
3550,
166,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
3551,
166,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
3552,
166,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
3553,
166,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
3554,
166,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
3555,
166,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
3556,
166,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
3557,
166,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
3558,
166,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
3559,
166,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
3560,
166,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3561,
166,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
3562,
166,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3563,
166,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
3564,
166,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
3565,
166,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
3566,
166,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
3567,
166,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
3568,
166,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
3569,
166,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
3570,
166,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
3571,
166,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3572,
166,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
3573,
166,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3574,
166,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
3575,
166,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
3576,
166,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
3577,
166,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
3578,
166,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3579,
166,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3580,
166,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3581,
166,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3582,
166,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
3583,
166,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3584,
166,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
3585,
166,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3586,
166,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3587,
166,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
3588,
166,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
3589,
166,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
3590,
166,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
3591,
166,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
3592,
166,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3593,
166,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
3594,
166,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
3595,
166,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3596,
166,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
3597,
166,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3598,
166,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3599,
166,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3600,
166,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3601,
166,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3602,
166,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3603,
166,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3604,
166,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3605,
166,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3606,
166,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3607,
166,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3608,
166,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3609,
166,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3610,
166,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
3611,
166,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
3612,
166,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
3613,
166,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3614,
166,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
3615,
166,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3616,
166,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
3617,
166,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3618,
166,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
3619,
166,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3620,
166,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
3621,
166,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3622,
166,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
3623,
166,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3624,
166,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
3625,
166,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3626,
166,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
3627,
166,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3628,
166,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
3629,
166,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3630,
166,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
3631,
166,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3632,
166,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3633,
166,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
3634,
166,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3635,
166,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
3636,
166,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3637,
166,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
3638,
166,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
3639,
166,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3640,
166,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
3641,
166,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3642,
166,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
3643,
166,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3644,
166,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3645,
166,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3646,
166,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3647,
166,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3648,
166,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
3649,
166,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3650,
166,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
3651,
166,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3652,
166,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3653,
166,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3654,
166,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3655,
166,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3656,
166,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3657,
166,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3658,
166,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
3659,
166,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3660,
166,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
3661,
166,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3662,
166,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3663,
166,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3664,
166,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3665,
166,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3666,
166,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3667,
166,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3668,
166,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
3669,
166,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3670,
166,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
3671,
166,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3672,
166,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3673,
166,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3674,
166,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3675,
166,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3676,
166,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3677,
166,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3678,
166,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
3679,
166,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3680,
166,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
3681,
166,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3682,
166,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3683,
166,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3684,
166,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3685,
166,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3686,
166,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3687,
166,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3688,
166,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
3689,
166,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3690,
166,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
3691,
166,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3692,
166,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3693,
166,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3694,
166,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3695,
166,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3696,
166,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3697,
166,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3698,
166,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
3699,
166,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
3700,
166,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
3701,
166,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
3702,
166,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
3703,
166,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
3704,
166,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
3705,
166,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
3706,
166,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
3707,
166,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
3708,
166,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3709,
166,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
3710,
166,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
3711,
166,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
3712,
166,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3713,
166,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
3714,
166,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
3715,
166,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
3716,
166,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
3717,
166,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
3718,
166,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3719,
166,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
3720,
166,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
3721,
166,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
3722,
166,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
3723,
166,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
3724,
166,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
3725,
166,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
3726,
166,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
3727,
166,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
3728,
166,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3729,
166,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
3730,
166,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
3731,
166,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
3732,
166,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
3733,
166,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
3734,
166,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
3735,
166,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
3736,
166,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3737,
166,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
3738,
166,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
3739,
166,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
3740,
166,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
3741,
166,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
3742,
166,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
3743,
166,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
3744,
166,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
3745,
166,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
3746,
166,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
3747,
166,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
3748,
166,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
3749,
166,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
3750,
166,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
3751,
166,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
3752,
166,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
3753,
166,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
3754,
166,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
3755,
166,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
3756,
166,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
3757,
166,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
3758,
166,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
3759,
166,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
3760,
166,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
3761,
166,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
3762,
166,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
3763,
166,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
3764,
166,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
3765,
166,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
3766,
166,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
3767,
166,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
3768,
166,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
3769,
166,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
3770,
166,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
3771,
166,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
3772,
166,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
3773,
166,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
3774,
166,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
3775,
166,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
3776,
166,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
3777,
166,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
3778,
166,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
3779,
166,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
3780,
166,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
3781,
166,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
3782,
166,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
3783,
166,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
3784,
166,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
3785,
166,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
3786,
166,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
3787,
166,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
3788,
166,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
3789,
166,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
3790,
166,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3791,
166,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
3792,
171,
'_wp_attached_file',
'2021/11/burger-icon.svg'
/* VALUES END */
), (
/* VALUES START */
3793,
171,
'_wp_attachment_metadata',
'a:4:{s:5:\"width\";i:40;s:6:\"height\";i:36;s:4:\"file\";s:24:\"/2021/11/burger-icon.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:15:\"burger-icon.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";b:0;s:4:\"file\";s:15:\"burger-icon.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";s:1:\"0\";s:4:\"crop\";b:0;s:4:\"file\";s:15:\"burger-icon.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1024\";s:4:\"crop\";b:0;s:4:\"file\";s:15:\"burger-icon.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"burger-icon.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";b:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"burger-icon.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'
/* VALUES END */
), (
/* VALUES START */
3794,
9,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
3795,
9,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
3796,
172,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
3797,
172,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
3798,
172,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
3799,
172,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
3800,
172,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
3801,
172,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
3802,
172,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
3803,
172,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
3804,
172,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3805,
172,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
3806,
172,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3807,
172,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
3808,
172,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
3809,
172,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
3810,
172,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
3811,
172,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
3812,
172,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
3813,
172,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
3814,
172,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3815,
172,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
3816,
172,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
3817,
172,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
3818,
172,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
3819,
172,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
3820,
172,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
3821,
172,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
3822,
172,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
3823,
172,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
3824,
172,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
3825,
172,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
3826,
172,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
3827,
172,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
3828,
172,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
3829,
172,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
3830,
172,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
3831,
172,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
3832,
172,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
3833,
172,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
3834,
172,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
3835,
172,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
3836,
172,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
3837,
172,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
3838,
172,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
3839,
172,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
3840,
172,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
3841,
172,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
3842,
172,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
3843,
172,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
3844,
172,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
3845,
172,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
3846,
172,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
3847,
172,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
3848,
172,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
3849,
172,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
3850,
172,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3851,
172,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
3852,
172,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
3853,
172,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
3854,
172,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
3855,
172,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
3856,
172,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
3857,
172,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
3858,
172,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
3859,
172,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3860,
172,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
3861,
172,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
3862,
172,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
3863,
172,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
3864,
172,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
3865,
172,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
3866,
172,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3867,
172,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3868,
172,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3869,
172,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3870,
172,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
3871,
172,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3872,
172,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
3873,
172,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3874,
172,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3875,
172,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
3876,
172,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
3877,
172,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
3878,
172,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
3879,
172,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
3880,
172,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3881,
172,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
3882,
172,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
3883,
172,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3884,
172,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
3885,
172,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3886,
172,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3887,
172,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3888,
172,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3889,
172,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3890,
172,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3891,
172,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3892,
172,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3893,
172,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3894,
172,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
3895,
172,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
3896,
172,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
3897,
172,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
3898,
172,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
3899,
172,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
3900,
172,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
3901,
172,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3902,
172,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
3903,
172,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3904,
172,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
3905,
172,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3906,
172,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
3907,
172,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3908,
172,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
3909,
172,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3910,
172,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
3911,
172,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3912,
172,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
3913,
172,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3914,
172,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
3915,
172,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3916,
172,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
3917,
172,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
3918,
172,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
3919,
172,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
3920,
172,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3921,
172,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
3922,
172,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
3923,
172,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
3924,
172,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
3925,
172,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
3926,
172,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
3927,
172,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3928,
172,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
3929,
172,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3930,
172,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
3931,
172,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3932,
172,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3933,
172,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3934,
172,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3935,
172,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3936,
172,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
3937,
172,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3938,
172,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
3939,
172,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3940,
172,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3941,
172,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3942,
172,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3943,
172,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3944,
172,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3945,
172,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3946,
172,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
3947,
172,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3948,
172,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
3949,
172,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3950,
172,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3951,
172,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3952,
172,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3953,
172,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3954,
172,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3955,
172,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3956,
172,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
3957,
172,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3958,
172,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
3959,
172,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3960,
172,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3961,
172,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3962,
172,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3963,
172,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3964,
172,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3965,
172,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3966,
172,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
3967,
172,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3968,
172,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
3969,
172,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3970,
172,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3971,
172,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3972,
172,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3973,
172,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3974,
172,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3975,
172,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3976,
172,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
3977,
172,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
3978,
172,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
3979,
172,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
3980,
172,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
3981,
172,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
3982,
172,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
3983,
172,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
3984,
172,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
3985,
172,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
3986,
172,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
3987,
172,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
3988,
172,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
3989,
172,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
3990,
172,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
3991,
172,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
3992,
172,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
3993,
172,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
3994,
172,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
3995,
172,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
3996,
172,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
3997,
172,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
3998,
172,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
3999,
172,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
4000,
172,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4001,
172,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
4002,
172,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
4003,
172,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
4004,
172,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
4005,
172,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
4006,
172,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4007,
172,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
4008,
172,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
4009,
172,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
4010,
172,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
4011,
172,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
4012,
172,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
4013,
172,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
4014,
172,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
4015,
172,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
4016,
172,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4017,
172,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
4018,
172,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
4019,
172,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
4020,
172,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4021,
172,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
4022,
172,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
4023,
172,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
4024,
172,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4025,
172,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
4026,
172,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
4027,
172,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
4028,
172,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4029,
172,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
4030,
172,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
4031,
172,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
4032,
172,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
4033,
172,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
4034,
172,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
4035,
172,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
4036,
172,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
4037,
172,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
4038,
172,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
4039,
172,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
4040,
172,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4041,
172,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
4042,
172,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
4043,
172,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
4044,
172,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
4045,
172,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
4046,
172,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4047,
172,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
4048,
172,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
4049,
172,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
4050,
172,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
4051,
172,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
4052,
172,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
4053,
172,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
4054,
172,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
4055,
172,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
4056,
172,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
4057,
172,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
4058,
172,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
4059,
172,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
4060,
172,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
4061,
172,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
4062,
172,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
4063,
172,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
4064,
172,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
4065,
172,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
4066,
172,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
4067,
172,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
4068,
172,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4069,
172,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
4070,
172,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
4071,
172,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
4072,
172,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4073,
172,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
4074,
172,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
4075,
172,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
4076,
172,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
4077,
172,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
4078,
172,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4079,
172,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
4080,
172,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
4081,
172,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
4082,
173,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
4083,
173,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
4084,
173,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
4085,
173,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
4086,
173,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
4087,
173,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
4088,
173,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
4089,
173,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
4090,
173,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4091,
173,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
4092,
173,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4093,
173,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
4094,
173,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
4095,
173,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
4096,
173,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
4097,
173,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
4098,
173,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
4099,
173,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
4100,
173,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4101,
173,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
4102,
173,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
4103,
173,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
4104,
173,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
4105,
173,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
4106,
173,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4107,
173,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
4108,
173,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
4109,
173,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
4110,
173,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4111,
173,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
4112,
173,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
4113,
173,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
4114,
173,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
4115,
173,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
4116,
173,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4117,
173,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
4118,
173,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4119,
173,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
4120,
173,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
4121,
173,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
4122,
173,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
4123,
173,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
4124,
173,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4125,
173,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
4126,
173,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
4127,
173,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
4128,
173,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
4129,
173,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
4130,
173,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
4131,
173,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
4132,
173,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n <span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
4133,
173,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
4134,
173,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4135,
173,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
4136,
173,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4137,
173,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
4138,
173,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
4139,
173,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
4140,
173,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
4141,
173,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
4142,
173,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
4143,
173,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
4144,
173,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
4145,
173,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
4146,
173,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
4147,
173,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
4148,
173,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
4149,
173,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
4150,
173,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
4151,
173,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
4152,
173,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4153,
173,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4154,
173,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4155,
173,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4156,
173,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
4157,
173,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4158,
173,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
4159,
173,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4160,
173,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
4161,
173,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
4162,
173,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
4163,
173,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
4164,
173,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
4165,
173,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
4166,
173,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4167,
173,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
4168,
173,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
4169,
173,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4170,
173,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
4171,
173,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4172,
173,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4173,
173,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4174,
173,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4175,
173,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4176,
173,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4177,
173,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4178,
173,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4179,
173,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4180,
173,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4181,
173,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4182,
173,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4183,
173,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4184,
173,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
4185,
173,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
4186,
173,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
4187,
173,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4188,
173,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
4189,
173,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4190,
173,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
4191,
173,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4192,
173,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
4193,
173,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4194,
173,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
4195,
173,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4196,
173,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
4197,
173,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4198,
173,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
4199,
173,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4200,
173,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
4201,
173,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4202,
173,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
4203,
173,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4204,
173,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
4205,
173,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4206,
173,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4207,
173,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
4208,
173,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4209,
173,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
4210,
173,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
4211,
173,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
4212,
173,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
4213,
173,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4214,
173,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
4215,
173,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4216,
173,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
4217,
173,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4218,
173,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4219,
173,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4220,
173,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4221,
173,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4222,
173,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
4223,
173,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4224,
173,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
4225,
173,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4226,
173,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4227,
173,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4228,
173,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4229,
173,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4230,
173,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4231,
173,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4232,
173,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
4233,
173,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4234,
173,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
4235,
173,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4236,
173,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4237,
173,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4238,
173,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4239,
173,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4240,
173,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4241,
173,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4242,
173,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
4243,
173,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4244,
173,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
4245,
173,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4246,
173,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4247,
173,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4248,
173,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4249,
173,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4250,
173,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4251,
173,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4252,
173,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
4253,
173,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4254,
173,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
4255,
173,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4256,
173,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4257,
173,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4258,
173,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4259,
173,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4260,
173,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4261,
173,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4262,
173,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
4263,
173,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4264,
173,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
4265,
173,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4266,
173,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4267,
173,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4268,
173,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4269,
173,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4270,
173,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4271,
173,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4272,
173,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
4273,
173,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
4274,
173,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
4275,
173,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
4276,
173,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
4277,
173,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
4278,
173,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
4279,
173,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
4280,
173,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
4281,
173,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
4282,
173,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4283,
173,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
4284,
173,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
4285,
173,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
4286,
173,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4287,
173,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
4288,
173,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
4289,
173,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
4290,
173,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
4291,
173,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
4292,
173,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4293,
173,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
4294,
173,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
4295,
173,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
4296,
173,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
4297,
173,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
4298,
173,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
4299,
173,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
4300,
173,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
4301,
173,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
4302,
173,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4303,
173,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
4304,
173,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
4305,
173,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
4306,
173,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4307,
173,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
4308,
173,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
4309,
173,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
4310,
173,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4311,
173,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
4312,
173,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
4313,
173,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
4314,
173,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4315,
173,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
4316,
173,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
4317,
173,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
4318,
173,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
4319,
173,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
4320,
173,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
4321,
173,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
4322,
173,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
4323,
173,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
4324,
173,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
4325,
173,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
4326,
173,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4327,
173,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
4328,
173,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
4329,
173,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
4330,
173,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
4331,
173,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
4332,
173,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4333,
173,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
4334,
173,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
4335,
173,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
4336,
173,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
4337,
173,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
4338,
173,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
4339,
173,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
4340,
173,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
4341,
173,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
4342,
173,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
4343,
173,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
4344,
173,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
4345,
173,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
4346,
173,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
4347,
173,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
4348,
173,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
4349,
173,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
4350,
173,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
4351,
173,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
4352,
173,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
4353,
173,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
4354,
173,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4355,
173,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
4356,
173,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
4357,
173,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
4358,
173,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4359,
173,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
4360,
173,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
4361,
173,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
4362,
173,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
4363,
173,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
4364,
173,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4365,
173,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
4366,
173,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
4367,
173,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
4368,
174,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
4369,
174,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
4370,
174,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
4371,
174,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
4372,
174,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
4373,
174,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
4374,
174,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
4375,
174,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
4376,
174,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4377,
174,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
4378,
174,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4379,
174,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
4380,
174,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
4381,
174,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
4382,
174,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
4383,
174,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
4384,
174,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
4385,
174,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
4386,
174,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4387,
174,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
4388,
174,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
4389,
174,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
4390,
174,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
4391,
174,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
4392,
174,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4393,
174,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
4394,
174,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
4395,
174,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
4396,
174,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4397,
174,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
4398,
174,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
4399,
174,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
4400,
174,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
4401,
174,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
4402,
174,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4403,
174,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
4404,
174,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4405,
174,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
4406,
174,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
4407,
174,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
4408,
174,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
4409,
174,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
4410,
174,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4411,
174,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
4412,
174,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
4413,
174,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
4414,
174,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
4415,
174,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
4416,
174,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
4417,
174,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
4418,
174,
'hero__box_hero__box-text',
'<span style=\"color: #ff0000;\">BUY AN</span>\r\nNFT MOON CERTIFICATE\r\nAND GET A\r\nVIRTUAL PIECE OF LAND\r\nIN THE MOON\r\nMETAVERSE'
/* VALUES END */
), (
/* VALUES START */
4419,
174,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
4420,
174,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4421,
174,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
4422,
174,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4423,
174,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
4424,
174,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
4425,
174,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
4426,
174,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
4427,
174,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
4428,
174,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
4429,
174,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
4430,
174,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
4431,
174,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
4432,
174,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
4433,
174,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
4434,
174,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
4435,
174,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
4436,
174,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
4437,
174,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
4438,
174,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4439,
174,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4440,
174,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4441,
174,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4442,
174,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
4443,
174,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4444,
174,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
4445,
174,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4446,
174,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
4447,
174,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
4448,
174,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
4449,
174,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
4450,
174,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
4451,
174,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
4452,
174,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4453,
174,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
4454,
174,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
4455,
174,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4456,
174,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
4457,
174,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4458,
174,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4459,
174,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4460,
174,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4461,
174,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4462,
174,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4463,
174,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4464,
174,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4465,
174,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4466,
174,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4467,
174,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4468,
174,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4469,
174,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4470,
174,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
4471,
174,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
4472,
174,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
4473,
174,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4474,
174,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
4475,
174,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4476,
174,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
4477,
174,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4478,
174,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
4479,
174,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4480,
174,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
4481,
174,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4482,
174,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
4483,
174,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4484,
174,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
4485,
174,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4486,
174,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
4487,
174,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4488,
174,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
4489,
174,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4490,
174,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
4491,
174,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4492,
174,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4493,
174,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
4494,
174,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4495,
174,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
4496,
174,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
4497,
174,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
4498,
174,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
4499,
174,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4500,
174,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
4501,
174,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4502,
174,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
4503,
174,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4504,
174,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4505,
174,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4506,
174,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4507,
174,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4508,
174,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
4509,
174,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4510,
174,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
4511,
174,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4512,
174,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4513,
174,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4514,
174,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4515,
174,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4516,
174,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4517,
174,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4518,
174,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
4519,
174,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4520,
174,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
4521,
174,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4522,
174,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4523,
174,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4524,
174,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4525,
174,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4526,
174,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4527,
174,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4528,
174,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
4529,
174,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4530,
174,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
4531,
174,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4532,
174,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4533,
174,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4534,
174,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4535,
174,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4536,
174,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4537,
174,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4538,
174,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
4539,
174,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4540,
174,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
4541,
174,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4542,
174,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4543,
174,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4544,
174,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4545,
174,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4546,
174,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4547,
174,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4548,
174,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
4549,
174,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4550,
174,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
4551,
174,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4552,
174,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4553,
174,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4554,
174,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4555,
174,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4556,
174,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4557,
174,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4558,
174,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
4559,
174,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
4560,
174,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
4561,
174,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
4562,
174,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
4563,
174,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
4564,
174,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
4565,
174,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
4566,
174,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
4567,
174,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
4568,
174,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4569,
174,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
4570,
174,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
4571,
174,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
4572,
174,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4573,
174,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
4574,
174,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
4575,
174,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
4576,
174,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
4577,
174,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
4578,
174,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4579,
174,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
4580,
174,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
4581,
174,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
4582,
174,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
4583,
174,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
4584,
174,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
4585,
174,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
4586,
174,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
4587,
174,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
4588,
174,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4589,
174,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
4590,
174,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
4591,
174,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
4592,
174,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4593,
174,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
4594,
174,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
4595,
174,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
4596,
174,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4597,
174,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
4598,
174,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
4599,
174,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
4600,
174,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4601,
174,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
4602,
174,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
4603,
174,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
4604,
174,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
4605,
174,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
4606,
174,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
4607,
174,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
4608,
174,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
4609,
174,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
4610,
174,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
4611,
174,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
4612,
174,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4613,
174,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
4614,
174,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
4615,
174,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
4616,
174,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
4617,
174,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
4618,
174,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4619,
174,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
4620,
174,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
4621,
174,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
4622,
174,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
4623,
174,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
4624,
174,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
4625,
174,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
4626,
174,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
4627,
174,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
4628,
174,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
4629,
174,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
4630,
174,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
4631,
174,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
4632,
174,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
4633,
174,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
4634,
174,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
4635,
174,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
4636,
174,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
4637,
174,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
4638,
174,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
4639,
174,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
4640,
174,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4641,
174,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
4642,
174,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
4643,
174,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
4644,
174,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4645,
174,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
4646,
174,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
4647,
174,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
4648,
174,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
4649,
174,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
4650,
174,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4651,
174,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
4652,
174,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
4653,
174,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
4654,
175,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
4655,
175,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
4656,
175,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
4657,
175,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
4658,
175,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
4659,
175,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
4660,
175,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
4661,
175,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
4662,
175,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4663,
175,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
4664,
175,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4665,
175,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
4666,
175,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
4667,
175,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
4668,
175,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
4669,
175,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
4670,
175,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
4671,
175,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
4672,
175,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4673,
175,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
4674,
175,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
4675,
175,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
4676,
175,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
4677,
175,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
4678,
175,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4679,
175,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
4680,
175,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
4681,
175,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
4682,
175,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4683,
175,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
4684,
175,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
4685,
175,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
4686,
175,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
4687,
175,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
4688,
175,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4689,
175,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
4690,
175,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4691,
175,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
4692,
175,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
4693,
175,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
4694,
175,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
4695,
175,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
4696,
175,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4697,
175,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
4698,
175,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
4699,
175,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
4700,
175,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
4701,
175,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
4702,
175,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
4703,
175,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
4704,
175,
'hero__box_hero__box-text',
'<span style=\"color: #000000;\">BUY AN</span>\r\nNFT MOON CERTIFICATE\r\nAND GET A\r\nVIRTUAL PIECE OF LAND\r\nIN THE MOON\r\nMETAVERSE'
/* VALUES END */
), (
/* VALUES START */
4705,
175,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
4706,
175,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4707,
175,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
4708,
175,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4709,
175,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
4710,
175,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
4711,
175,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
4712,
175,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
4713,
175,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
4714,
175,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
4715,
175,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
4716,
175,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
4717,
175,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
4718,
175,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
4719,
175,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
4720,
175,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
4721,
175,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
4722,
175,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
4723,
175,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
4724,
175,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4725,
175,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4726,
175,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4727,
175,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4728,
175,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
4729,
175,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4730,
175,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
4731,
175,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4732,
175,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
4733,
175,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
4734,
175,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
4735,
175,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
4736,
175,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
4737,
175,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
4738,
175,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4739,
175,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
4740,
175,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
4741,
175,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4742,
175,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
4743,
175,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4744,
175,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4745,
175,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4746,
175,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4747,
175,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4748,
175,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4749,
175,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4750,
175,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4751,
175,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4752,
175,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
4753,
175,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
4754,
175,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
4755,
175,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
4756,
175,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
4757,
175,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
4758,
175,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
4759,
175,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4760,
175,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
4761,
175,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4762,
175,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
4763,
175,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4764,
175,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
4765,
175,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4766,
175,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
4767,
175,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4768,
175,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
4769,
175,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4770,
175,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
4771,
175,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4772,
175,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
4773,
175,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4774,
175,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
4775,
175,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
4776,
175,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
4777,
175,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
4778,
175,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4779,
175,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
4780,
175,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4781,
175,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
4782,
175,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
4783,
175,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
4784,
175,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
4785,
175,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4786,
175,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
4787,
175,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4788,
175,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
4789,
175,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4790,
175,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4791,
175,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4792,
175,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4793,
175,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4794,
175,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
4795,
175,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4796,
175,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
4797,
175,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4798,
175,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4799,
175,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4800,
175,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4801,
175,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4802,
175,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4803,
175,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4804,
175,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
4805,
175,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4806,
175,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
4807,
175,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4808,
175,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4809,
175,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4810,
175,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4811,
175,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4812,
175,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4813,
175,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4814,
175,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
4815,
175,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4816,
175,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
4817,
175,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4818,
175,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4819,
175,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4820,
175,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4821,
175,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4822,
175,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4823,
175,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4824,
175,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
4825,
175,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4826,
175,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
4827,
175,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4828,
175,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4829,
175,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4830,
175,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4831,
175,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4832,
175,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4833,
175,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4834,
175,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
4835,
175,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
4836,
175,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
4837,
175,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
4838,
175,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
4839,
175,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
4840,
175,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4841,
175,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
4842,
175,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
4843,
175,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
4844,
175,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
4845,
175,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
4846,
175,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
4847,
175,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
4848,
175,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
4849,
175,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
4850,
175,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
4851,
175,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
4852,
175,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
4853,
175,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
4854,
175,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4855,
175,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
4856,
175,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
4857,
175,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
4858,
175,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4859,
175,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
4860,
175,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
4861,
175,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
4862,
175,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
4863,
175,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
4864,
175,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4865,
175,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
4866,
175,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
4867,
175,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
4868,
175,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
4869,
175,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
4870,
175,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
4871,
175,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
4872,
175,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
4873,
175,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
4874,
175,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4875,
175,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
4876,
175,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
4877,
175,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
4878,
175,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4879,
175,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
4880,
175,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
4881,
175,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
4882,
175,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4883,
175,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
4884,
175,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
4885,
175,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
4886,
175,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4887,
175,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
4888,
175,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
4889,
175,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
4890,
175,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
4891,
175,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
4892,
175,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
4893,
175,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
4894,
175,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
4895,
175,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
4896,
175,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
4897,
175,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
4898,
175,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4899,
175,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
4900,
175,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
4901,
175,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
4902,
175,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
4903,
175,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
4904,
175,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4905,
175,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
4906,
175,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
4907,
175,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
4908,
175,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
4909,
175,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
4910,
175,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
4911,
175,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
4912,
175,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
4913,
175,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
4914,
175,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
4915,
175,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
4916,
175,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
4917,
175,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
4918,
175,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
4919,
175,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
4920,
175,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
4921,
175,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
4922,
175,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
4923,
175,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
4924,
175,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
4925,
175,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
4926,
175,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4927,
175,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
4928,
175,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
4929,
175,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
4930,
175,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
4931,
175,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
4932,
175,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
4933,
175,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
4934,
175,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
4935,
175,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
4936,
175,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
4937,
175,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
4938,
175,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
4939,
175,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
4940,
176,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
4941,
176,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
4942,
176,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
4943,
176,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
4944,
176,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
4945,
176,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
4946,
176,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
4947,
176,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
4948,
176,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4949,
176,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
4950,
176,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
4951,
176,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
4952,
176,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
4953,
176,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
4954,
176,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
4955,
176,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
4956,
176,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
4957,
176,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
4958,
176,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4959,
176,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
4960,
176,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
4961,
176,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
4962,
176,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
4963,
176,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
4964,
176,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
4965,
176,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
4966,
176,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
4967,
176,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
4968,
176,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
4969,
176,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
4970,
176,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
4971,
176,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
4972,
176,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
4973,
176,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
4974,
176,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
4975,
176,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
4976,
176,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
4977,
176,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
4978,
176,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
4979,
176,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
4980,
176,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
4981,
176,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
4982,
176,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
4983,
176,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
4984,
176,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
4985,
176,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
4986,
176,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
4987,
176,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
4988,
176,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
4989,
176,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
4990,
176,
'hero__box_hero__box-text',
'BUY AN\r\nNFT MOON CERTIFICATE\r\nAND GET A\r\nVIRTUAL PIECE OF LAND\r\nIN THE MOON\r\nMETAVERSE'
/* VALUES END */
), (
/* VALUES START */
4991,
176,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
4992,
176,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
4993,
176,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
4994,
176,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
4995,
176,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
4996,
176,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
4997,
176,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
4998,
176,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
4999,
176,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
5000,
176,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
5001,
176,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
5002,
176,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
5003,
176,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
5004,
176,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
5005,
176,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
5006,
176,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
5007,
176,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
5008,
176,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
5009,
176,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
5010,
176,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5011,
176,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5012,
176,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5013,
176,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5014,
176,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
5015,
176,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5016,
176,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
5017,
176,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5018,
176,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
5019,
176,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
5020,
176,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
5021,
176,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
5022,
176,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
5023,
176,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
5024,
176,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5025,
176,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
5026,
176,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
5027,
176,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5028,
176,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
5029,
176,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5030,
176,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5031,
176,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5032,
176,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5033,
176,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5034,
176,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5035,
176,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5036,
176,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5037,
176,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5038,
176,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5039,
176,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5040,
176,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5041,
176,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5042,
176,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
5043,
176,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
5044,
176,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
5045,
176,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5046,
176,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
5047,
176,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5048,
176,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
5049,
176,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5050,
176,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
5051,
176,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5052,
176,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
5053,
176,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5054,
176,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
5055,
176,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5056,
176,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
5057,
176,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5058,
176,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
5059,
176,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5060,
176,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
5061,
176,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5062,
176,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
5063,
176,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5064,
176,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5065,
176,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
5066,
176,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5067,
176,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
5068,
176,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
5069,
176,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
5070,
176,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
5071,
176,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5072,
176,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
5073,
176,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5074,
176,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
5075,
176,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5076,
176,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5077,
176,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5078,
176,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5079,
176,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5080,
176,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
5081,
176,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5082,
176,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
5083,
176,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5084,
176,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5085,
176,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5086,
176,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5087,
176,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5088,
176,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5089,
176,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5090,
176,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
5091,
176,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5092,
176,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
5093,
176,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5094,
176,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5095,
176,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5096,
176,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5097,
176,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5098,
176,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5099,
176,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5100,
176,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
5101,
176,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5102,
176,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
5103,
176,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5104,
176,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5105,
176,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5106,
176,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5107,
176,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5108,
176,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5109,
176,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5110,
176,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
5111,
176,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5112,
176,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
5113,
176,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5114,
176,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5115,
176,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5116,
176,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5117,
176,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5118,
176,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5119,
176,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5120,
176,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
5121,
176,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5122,
176,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
5123,
176,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5124,
176,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5125,
176,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5126,
176,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5127,
176,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5128,
176,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5129,
176,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5130,
176,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
5131,
176,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
5132,
176,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
5133,
176,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
5134,
176,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
5135,
176,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
5136,
176,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
5137,
176,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
5138,
176,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
5139,
176,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
5140,
176,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5141,
176,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
5142,
176,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
5143,
176,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
5144,
176,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5145,
176,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
5146,
176,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
5147,
176,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
5148,
176,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
5149,
176,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
5150,
176,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5151,
176,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
5152,
176,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
5153,
176,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
5154,
176,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
5155,
176,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
5156,
176,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
5157,
176,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
5158,
176,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
5159,
176,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
5160,
176,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5161,
176,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
5162,
176,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
5163,
176,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
5164,
176,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
5165,
176,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
5166,
176,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
5167,
176,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
5168,
176,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5169,
176,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
5170,
176,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
5171,
176,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
5172,
176,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
5173,
176,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
5174,
176,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
5175,
176,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
5176,
176,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
5177,
176,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
5178,
176,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
5179,
176,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
5180,
176,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
5181,
176,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
5182,
176,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
5183,
176,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
5184,
176,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
5185,
176,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
5186,
176,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
5187,
176,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
5188,
176,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
5189,
176,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
5190,
176,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
5191,
176,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
5192,
176,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
5193,
176,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
5194,
176,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
5195,
176,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
5196,
176,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
5197,
176,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
5198,
176,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
5199,
176,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
5200,
176,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
5201,
176,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
5202,
176,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
5203,
176,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
5204,
176,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
5205,
176,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
5206,
176,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
5207,
176,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
5208,
176,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
5209,
176,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
5210,
176,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
5211,
176,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
5212,
176,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
5213,
176,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
5214,
176,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
5215,
176,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
5216,
176,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
5217,
176,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
5218,
176,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
5219,
176,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
5220,
176,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
5221,
176,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
5222,
176,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5223,
176,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
5224,
176,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
5225,
176,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
5226,
177,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
5227,
177,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
5228,
177,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
5229,
177,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
5230,
177,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
5231,
177,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
5232,
177,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
5233,
177,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
5234,
177,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5235,
177,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
5236,
177,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5237,
177,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
5238,
177,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
5239,
177,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
5240,
177,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
5241,
177,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
5242,
177,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
5243,
177,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
5244,
177,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5245,
177,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
5246,
177,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
5247,
177,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
5248,
177,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
5249,
177,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
5250,
177,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
5251,
177,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
5252,
177,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
5253,
177,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
5254,
177,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
5255,
177,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
5256,
177,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
5257,
177,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
5258,
177,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
5259,
177,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
5260,
177,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
5261,
177,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
5262,
177,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5263,
177,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
5264,
177,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
5265,
177,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
5266,
177,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
5267,
177,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
5268,
177,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
5269,
177,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
5270,
177,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
5271,
177,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
5272,
177,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
5273,
177,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
5274,
177,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them. <br>\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
5275,
177,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
5276,
177,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n<span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
5277,
177,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
5278,
177,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5279,
177,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
5280,
177,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5281,
177,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
5282,
177,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
5283,
177,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
5284,
177,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
5285,
177,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
5286,
177,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
5287,
177,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
5288,
177,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
5289,
177,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
5290,
177,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
5291,
177,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
5292,
177,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
5293,
177,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
5294,
177,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
5295,
177,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
5296,
177,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5297,
177,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5298,
177,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5299,
177,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5300,
177,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
5301,
177,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5302,
177,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
5303,
177,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5304,
177,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
5305,
177,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
5306,
177,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
5307,
177,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
5308,
177,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
5309,
177,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
5310,
177,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5311,
177,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
5312,
177,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
5313,
177,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5314,
177,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
5315,
177,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5316,
177,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5317,
177,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5318,
177,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5319,
177,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5320,
177,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5321,
177,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5322,
177,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5323,
177,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5324,
177,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5325,
177,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5326,
177,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5327,
177,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5328,
177,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
5329,
177,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
5330,
177,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
5331,
177,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5332,
177,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
5333,
177,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5334,
177,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
5335,
177,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5336,
177,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
5337,
177,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5338,
177,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
5339,
177,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5340,
177,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
5341,
177,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5342,
177,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
5343,
177,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5344,
177,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
5345,
177,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5346,
177,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
5347,
177,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5348,
177,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
5349,
177,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5350,
177,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5351,
177,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
5352,
177,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5353,
177,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
5354,
177,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
5355,
177,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
5356,
177,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
5357,
177,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5358,
177,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
5359,
177,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5360,
177,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
5361,
177,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5362,
177,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5363,
177,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5364,
177,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5365,
177,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5366,
177,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
5367,
177,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5368,
177,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
5369,
177,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5370,
177,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5371,
177,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5372,
177,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5373,
177,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5374,
177,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5375,
177,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5376,
177,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
5377,
177,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5378,
177,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
5379,
177,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5380,
177,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5381,
177,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5382,
177,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5383,
177,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5384,
177,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5385,
177,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5386,
177,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
5387,
177,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5388,
177,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
5389,
177,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5390,
177,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5391,
177,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5392,
177,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5393,
177,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5394,
177,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5395,
177,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5396,
177,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
5397,
177,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5398,
177,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
5399,
177,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5400,
177,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5401,
177,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5402,
177,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5403,
177,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5404,
177,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5405,
177,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5406,
177,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
5407,
177,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5408,
177,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
5409,
177,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5410,
177,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5411,
177,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5412,
177,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5413,
177,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5414,
177,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5415,
177,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5416,
177,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
5417,
177,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
5418,
177,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
5419,
177,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
5420,
177,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
5421,
177,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
5422,
177,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
5423,
177,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
5424,
177,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
5425,
177,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
5426,
177,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5427,
177,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
5428,
177,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
5429,
177,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
5430,
177,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5431,
177,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
5432,
177,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
5433,
177,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
5434,
177,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
5435,
177,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
5436,
177,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5437,
177,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
5438,
177,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
5439,
177,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
5440,
177,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
5441,
177,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
5442,
177,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
5443,
177,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
5444,
177,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
5445,
177,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
5446,
177,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5447,
177,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
5448,
177,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
5449,
177,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
5450,
177,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
5451,
177,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
5452,
177,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
5453,
177,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
5454,
177,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5455,
177,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
5456,
177,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
5457,
177,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
5458,
177,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
5459,
177,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
5460,
177,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
5461,
177,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
5462,
177,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
5463,
177,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
5464,
177,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
5465,
177,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
5466,
177,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
5467,
177,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
5468,
177,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
5469,
177,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
5470,
177,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
5471,
177,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
5472,
177,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
5473,
177,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
5474,
177,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
5475,
177,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
5476,
177,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
5477,
177,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
5478,
177,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
5479,
177,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
5480,
177,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
5481,
177,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
5482,
177,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
5483,
177,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
5484,
177,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
5485,
177,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
5486,
177,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
5487,
177,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
5488,
177,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
5489,
177,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
5490,
177,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
5491,
177,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
5492,
177,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
5493,
177,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
5494,
177,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
5495,
177,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
5496,
177,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
5497,
177,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
5498,
177,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
5499,
177,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
5500,
177,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
5501,
177,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
5502,
177,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
5503,
177,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
5504,
177,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
5505,
177,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
5506,
177,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
5507,
177,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
5508,
177,
'roadmap__wrapper',
''
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
5509,
177,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
5510,
177,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
5511,
177,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
5512,
9,
'hero__box_hero__box-color',
'#92f8ff'
/* VALUES END */
), (
/* VALUES START */
5513,
9,
'_hero__box_hero__box-color',
'field_61a0d0d88226e'
/* VALUES END */
), (
/* VALUES START */
5514,
179,
'header__logo-link',
31
/* VALUES END */
), (
/* VALUES START */
5515,
179,
'_header__logo-link',
'field_619e37d4c65d2'
/* VALUES END */
), (
/* VALUES START */
5516,
179,
'header__menu-list_header__menu-list-item-1',
'MOON TOKEN'
/* VALUES END */
), (
/* VALUES START */
5517,
179,
'_header__menu-list_header__menu-list-item-1',
'field_619e3c274af30'
/* VALUES END */
), (
/* VALUES START */
5518,
179,
'header__menu-list_header__menu-list-link-1',
'#hero'
/* VALUES END */
), (
/* VALUES START */
5519,
179,
'_header__menu-list_header__menu-list-link-1',
'field_619e3d114af38'
/* VALUES END */
), (
/* VALUES START */
5520,
179,
'header__menu-list_header__menu-list-item-2',
'BUY'
/* VALUES END */
), (
/* VALUES START */
5521,
179,
'_header__menu-list_header__menu-list-item-2',
'field_619e3c974af32'
/* VALUES END */
), (
/* VALUES START */
5522,
179,
'header__menu-list_header__menu-list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5523,
179,
'_header__menu-list_header__menu-list-link-2',
'field_619e3dc64af39'
/* VALUES END */
), (
/* VALUES START */
5524,
179,
'header__menu-list_header__menu-list-item-3',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5525,
179,
'_header__menu-list_header__menu-list-item-3',
'field_619e3c984af33'
/* VALUES END */
), (
/* VALUES START */
5526,
179,
'header__menu-list_header__menu-list-link-3',
'#types'
/* VALUES END */
), (
/* VALUES START */
5527,
179,
'_header__menu-list_header__menu-list-link-3',
'field_619e3dc74af3a'
/* VALUES END */
), (
/* VALUES START */
5528,
179,
'header__menu-list_header__menu-list-item-4',
'ABOUT NFT MOON'
/* VALUES END */
), (
/* VALUES START */
5529,
179,
'_header__menu-list_header__menu-list-item-4',
'field_619e3c9a4af34'
/* VALUES END */
), (
/* VALUES START */
5530,
179,
'header__menu-list_header__menu-list-link-4',
'#about'
/* VALUES END */
), (
/* VALUES START */
5531,
179,
'_header__menu-list_header__menu-list-link-4',
'field_619e3dc84af3b'
/* VALUES END */
), (
/* VALUES START */
5532,
179,
'header__menu-list_header__menu-list-item-5',
'CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5533,
179,
'_header__menu-list_header__menu-list-item-5',
'field_619e3c9b4af35'
/* VALUES END */
), (
/* VALUES START */
5534,
179,
'header__menu-list_header__menu-list-link-5',
'#exchange'
/* VALUES END */
), (
/* VALUES START */
5535,
179,
'_header__menu-list_header__menu-list-link-5',
'field_619e3dc94af3c'
/* VALUES END */
), (
/* VALUES START */
5536,
179,
'header__menu-list_header__menu-list-item-6',
'SCHEDULE'
/* VALUES END */
), (
/* VALUES START */
5537,
179,
'_header__menu-list_header__menu-list-item-6',
'field_619e3c9c4af36'
/* VALUES END */
), (
/* VALUES START */
5538,
179,
'header__menu-list_header__menu-list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
5539,
179,
'_header__menu-list_header__menu-list-link-6',
'field_619e3dca4af3d'
/* VALUES END */
), (
/* VALUES START */
5540,
179,
'header__menu-list_header__menu-list-item-7',
'MORE'
/* VALUES END */
), (
/* VALUES START */
5541,
179,
'_header__menu-list_header__menu-list-item-7',
'field_619e3c9d4af37'
/* VALUES END */
), (
/* VALUES START */
5542,
179,
'header__menu-list_header__menu-list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
5543,
179,
'_header__menu-list_header__menu-list-link-7',
'field_619e3dcc4af3e'
/* VALUES END */
), (
/* VALUES START */
5544,
179,
'header__menu-list',
''
/* VALUES END */
), (
/* VALUES START */
5545,
179,
'_header__menu-list',
'field_619e3be34af2f'
/* VALUES END */
), (
/* VALUES START */
5546,
179,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'Link 1'
/* VALUES END */
), (
/* VALUES START */
5547,
179,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-1',
'field_619e41b7095b5'
/* VALUES END */
), (
/* VALUES START */
5548,
179,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
5549,
179,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-1',
'field_619e4277095b9'
/* VALUES END */
), (
/* VALUES START */
5550,
179,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5551,
179,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-2',
'field_619e42b3095ba'
/* VALUES END */
), (
/* VALUES START */
5552,
179,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'Link 2'
/* VALUES END */
), (
/* VALUES START */
5553,
179,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-2',
'field_619e4225095b7'
/* VALUES END */
), (
/* VALUES START */
5554,
179,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'Link 3'
/* VALUES END */
), (
/* VALUES START */
5555,
179,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-3',
'field_619e4228095b8'
/* VALUES END */
), (
/* VALUES START */
5556,
179,
'header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
5557,
179,
'_header__menu-list_header__menu-list-item-dropdown_dropdown-content-link-3',
'field_619e42b6095bb'
/* VALUES END */
), (
/* VALUES START */
5558,
179,
'header__menu-list_header__menu-list-item-dropdown',
''
/* VALUES END */
), (
/* VALUES START */
5559,
179,
'_header__menu-list_header__menu-list-item-dropdown',
'field_619e4199095b4'
/* VALUES END */
), (
/* VALUES START */
5560,
179,
'hero__info-title',
'WE ARE CREATING A <span>BLOCKCHAIN  <span class=\"color\">METAVERSE</span></span>'
/* VALUES END */
), (
/* VALUES START */
5561,
179,
'_hero__info-title',
'field_619e4a57831d4'
/* VALUES END */
), (
/* VALUES START */
5562,
179,
'hero__info-description',
'NFT MOON is a unique certificate (token) of virtual land plots \r\nwith unique properties that makes you a co-owner of the \r\nMoon metaverse and allows you to: create states, cities, \r\neconomies, items. Rent out land plots and sell them.\r\nMake a profit as a co-owner oh the game. '
/* VALUES END */
), (
/* VALUES START */
5563,
179,
'_hero__info-description',
'field_619e4abe831d5'
/* VALUES END */
), (
/* VALUES START */
5564,
179,
'hero__box_hero__box-text',
'BUY AN\r\n<span>NFT MOON CERTIFICATE</span>\r\nAND GET A\r\n<span>VIRTUAL PIECE OF LAND</span>\r\nIN THE MOON\r\n<span>METAVERSE</span>'
/* VALUES END */
), (
/* VALUES START */
5565,
179,
'_hero__box_hero__box-text',
'field_619e4b33831d7'
/* VALUES END */
), (
/* VALUES START */
5566,
179,
'hero__box_hero__box-inner_hero__box-link-text',
'<span>BUY NFT</span> CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5567,
179,
'_hero__box_hero__box-inner_hero__box-link-text',
'field_619e4c52831d9'
/* VALUES END */
), (
/* VALUES START */
5568,
179,
'hero__box_hero__box-inner_hero__box-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5569,
179,
'_hero__box_hero__box-inner_hero__box-link',
'field_619e4c99831da'
/* VALUES END */
), (
/* VALUES START */
5570,
179,
'hero__box_hero__box-inner_hero__box-link-color',
'#f2da00'
/* VALUES END */
), (
/* VALUES START */
5571,
179,
'_hero__box_hero__box-inner_hero__box-link-color',
'field_619e4cd5831db'
/* VALUES END */
), (
/* VALUES START */
5572,
179,
'hero__box_hero__box-inner',
''
/* VALUES END */
), (
/* VALUES START */
5573,
179,
'_hero__box_hero__box-inner',
'field_619e4b53831d8'
/* VALUES END */
), (
/* VALUES START */
5574,
179,
'hero__box',
''
/* VALUES END */
), (
/* VALUES START */
5575,
179,
'_hero__box',
'field_619e4adb831d6'
/* VALUES END */
), (
/* VALUES START */
5576,
179,
'hero__box_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
5577,
179,
'_hero__box_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
5578,
179,
'hero__box_hero__box-inner_hero__box-moon',
57
/* VALUES END */
), (
/* VALUES START */
5579,
179,
'_hero__box_hero__box-inner_hero__box-moon',
'field_619e52c849016'
/* VALUES END */
), (
/* VALUES START */
5580,
179,
'total',
'10.000 NFT'
/* VALUES END */
), (
/* VALUES START */
5581,
179,
'_total',
'field_619e5b8022f37'
/* VALUES END */
), (
/* VALUES START */
5582,
179,
'what__title',
'WHAT IS THE MOON METAVERSE?'
/* VALUES END */
), (
/* VALUES START */
5583,
179,
'_what__title',
'field_619e5c5222f38'
/* VALUES END */
), (
/* VALUES START */
5584,
179,
'what__wrapper_0_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5585,
179,
'_what__wrapper_0_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5586,
179,
'what__wrapper_0_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5587,
179,
'_what__wrapper_0_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5588,
179,
'what__wrapper_1_what__item-title',
'Where does any construction start?'
/* VALUES END */
), (
/* VALUES START */
5589,
179,
'_what__wrapper_1_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5590,
179,
'what__wrapper_1_what__item-text',
' We have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.\r\n\r\nWe have allocated 10,000 land plots on the Virtual Moon. That is, there will be 10,000 NFT Moon certificate holders. A total of 6 levels of uniqueness of certificates and the sites to which they are linked.'
/* VALUES END */
), (
/* VALUES START */
5591,
179,
'_what__wrapper_1_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5592,
179,
'what__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
5593,
179,
'_what__wrapper',
'field_619e5c7222f39'
/* VALUES END */
), (
/* VALUES START */
5594,
179,
'faq__wrapper_faq__image',
76
/* VALUES END */
), (
/* VALUES START */
5595,
179,
'_faq__wrapper_faq__image',
'field_619e5e86990a5'
/* VALUES END */
), (
/* VALUES START */
5596,
179,
'faq__wrapper_faq__title',
'Frequently\r\nAsked\r\nQuestions'
/* VALUES END */
), (
/* VALUES START */
5597,
179,
'_faq__wrapper_faq__title',
'field_619e5f4c990a6'
/* VALUES END */
), (
/* VALUES START */
5598,
179,
'faq__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5599,
179,
'_faq__wrapper',
'field_619e5dfa990a4'
/* VALUES END */
), (
/* VALUES START */
5600,
179,
'what__wrapper_2_what__item-title',
'What is the level of uniqueness?'
/* VALUES END */
), (
/* VALUES START */
5601,
179,
'_what__wrapper_2_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5602,
179,
'what__wrapper_2_what__item-text',
'This is a set of characteristics. It includes:\r\n\r\n- The certificate itself by color level.\r\n\r\n– Powers (influence in the metaverse, receiving bonuses and privileges, belonging to a level).'
/* VALUES END */
), (
/* VALUES START */
5603,
179,
'_what__wrapper_2_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5604,
179,
'what__wrapper_3_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5605,
179,
'_what__wrapper_3_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5606,
179,
'what__wrapper_3_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5607,
179,
'_what__wrapper_3_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5608,
179,
'what__wrapper_4_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5609,
179,
'_what__wrapper_4_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5610,
179,
'what__wrapper_4_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5611,
179,
'_what__wrapper_4_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5612,
179,
'what__wrapper_5_what__item-title',
'NFT Moon is a virtual certificate for the virtual land plots in the Moon Metaverse.'
/* VALUES END */
), (
/* VALUES START */
5613,
179,
'_what__wrapper_5_what__item-title',
'field_619e5c8522f3a'
/* VALUES END */
), (
/* VALUES START */
5614,
179,
'what__wrapper_5_what__item-text',
'Imagine our Moon, it has a size, a landscape, and coordinates. My team and I are creating a virtual analogue of our moon, which exactly repeats all the characteristics and coordinates.  And the task is to make the Moon habitable!'
/* VALUES END */
), (
/* VALUES START */
5615,
179,
'_what__wrapper_5_what__item-text',
'field_619e5cda22f3b'
/* VALUES END */
), (
/* VALUES START */
5616,
179,
'faq__accordion',
5
/* VALUES END */
), (
/* VALUES START */
5617,
179,
'_faq__accordion',
'field_619e5f79fed3d'
/* VALUES END */
), (
/* VALUES START */
5618,
179,
'faq__accordion_0_faq__accordion-trigger',
'How many NFT Moon certificates appear every day?'
/* VALUES END */
), (
/* VALUES START */
5619,
179,
'_faq__accordion_0_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5620,
179,
'faq__accordion_0_faq__accordion-content',
'From 1 to 20 NFT Moon certificates of different levels are issued every day. That creates a shortage. In total, it is planned to issue certificates in a period of 1 to 7 years. Any newly issued certificate not sold during this period will be burned, creating an even greater shortage.\r\n\r\nAll certificates are completely transparent, meaning you can see which certificate has appeared and to what level it belongs.'
/* VALUES END */
), (
/* VALUES START */
5621,
179,
'_faq__accordion_0_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5622,
179,
'faq__accordion_1_faq__accordion-trigger',
'Why such a spread in time?'
/* VALUES END */
), (
/* VALUES START */
5623,
179,
'_faq__accordion_1_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5624,
179,
'faq__accordion_1_faq__accordion-content',
'It all depends on the supply and demand for NFT Moon certificates. Our task is to make sure that even before the game is released, the value and price of certificates grow.\r\n\r\nFor example, now only 13 NFT Moon certificates are issued and no more than 1 NFT Moon appears every day. As soon as We see that the demand is growing strongly, we start to produce not 1, but 5…. 20 NFT certificates per day. At the same time, due to the shortage, the new owners of NFT Moon can also sell their NFT Moon, but at a more expensive price.'
/* VALUES END */
), (
/* VALUES START */
5625,
179,
'_faq__accordion_1_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5626,
179,
'faq__accordion_2_faq__accordion-trigger',
'The game mechanics of the future game'
/* VALUES END */
), (
/* VALUES START */
5627,
179,
'_faq__accordion_2_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5628,
179,
'faq__accordion_2_faq__accordion-content',
'Imagine that there are already neighbors near your plot and their number is growing every day. You unite into settlements, cities. Build your house first, then a village, then a city. And just at this level, the levels of ownership begin to act. The higher the level of NFT Moon, the more bonuses and privileges the Moon universe gives you. And so you decided to create a state, create your own currency, economy. There is a voting system. You can name your land plot, settlement, or city by your own name. You can sell or buy anything you want inside Moon. And each virtual object is a separate NFT.\r\n\r\nLife begins to swirl around us. More and more people want to get into the virtual planet Moon. But there are no plots! They’ve all been sold out. And so you, as the owner of the NFT Moon certificate, decide to sell it to a new participant. And the price for it is already 10 … 100 times more expensive. Since there are no more plots.'
/* VALUES END */
), (
/* VALUES START */
5629,
179,
'_faq__accordion_2_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5630,
179,
'faq__accordion_3_faq__accordion-trigger',
'What about now?'
/* VALUES END */
), (
/* VALUES START */
5631,
179,
'_faq__accordion_3_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5632,
179,
'faq__accordion_3_faq__accordion-content',
'Now you can choose and buy your unique NFT Moon certificate. Become a part of the community of NFT Moon owners and immediately start getting to know each other. Even now, create relationships-even before the game is released.\r\n\r\nIn fact, you are now buying entrance to a closed club.'
/* VALUES END */
), (
/* VALUES START */
5633,
179,
'_faq__accordion_3_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5634,
179,
'faq__accordion_4_faq__accordion-trigger',
'And what is the level of Genesis?'
/* VALUES END */
), (
/* VALUES START */
5635,
179,
'_faq__accordion_4_faq__accordion-trigger',
'field_619e5feafed3e'
/* VALUES END */
), (
/* VALUES START */
5636,
179,
'faq__accordion_4_faq__accordion-content',
'This is the only NFT Moon certificate. It will appear after (see the counter below). It is unlike any other NFT Moon certificate. It allows you to earn revenue within the Moon metaverse from all purchase and sale transactions. Just imagine, Genesis is, in fact, the progenitor of all NFT Moons.\r\n\r\nWe are waiting for you in the virtual world of NFT Moon.'
/* VALUES END */
), (
/* VALUES START */
5637,
179,
'_faq__accordion_4_faq__accordion-content',
'field_619e6051fed3f'
/* VALUES END */
), (
/* VALUES START */
5638,
179,
'types__title',
'TYPES OF OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5639,
179,
'_types__title',
'field_619e6e55a10f7'
/* VALUES END */
), (
/* VALUES START */
5640,
179,
'types__subtitle',
'CHOOSE ONE OF OUR OWNERSHIP'
/* VALUES END */
), (
/* VALUES START */
5641,
179,
'_types__subtitle',
'field_619e6f8ba10f8'
/* VALUES END */
), (
/* VALUES START */
5642,
179,
'types__wrapper',
6
/* VALUES END */
), (
/* VALUES START */
5643,
179,
'_types__wrapper',
'field_619e6fa6a10f9'
/* VALUES END */
), (
/* VALUES START */
5644,
179,
'types__wrapper_0_types__item-image',
92
/* VALUES END */
), (
/* VALUES START */
5645,
179,
'_types__wrapper_0_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5646,
179,
'types__wrapper_0_types__item-image-phone',
93
/* VALUES END */
), (
/* VALUES START */
5647,
179,
'_types__wrapper_0_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5648,
179,
'types__wrapper_0_types__item-link-text',
'PLACE A BID'
/* VALUES END */
), (
/* VALUES START */
5649,
179,
'_types__wrapper_0_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5650,
179,
'types__wrapper_0_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5651,
179,
'_types__wrapper_0_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5652,
179,
'types__wrapper_0_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5653,
179,
'_types__wrapper_0_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5654,
179,
'types__wrapper_1_types__item-image',
94
/* VALUES END */
), (
/* VALUES START */
5655,
179,
'_types__wrapper_1_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5656,
179,
'types__wrapper_1_types__item-image-phone',
95
/* VALUES END */
), (
/* VALUES START */
5657,
179,
'_types__wrapper_1_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5658,
179,
'types__wrapper_1_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5659,
179,
'_types__wrapper_1_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5660,
179,
'types__wrapper_1_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5661,
179,
'_types__wrapper_1_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5662,
179,
'types__wrapper_1_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5663,
179,
'_types__wrapper_1_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5664,
179,
'types__wrapper_2_types__item-image',
96
/* VALUES END */
), (
/* VALUES START */
5665,
179,
'_types__wrapper_2_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5666,
179,
'types__wrapper_2_types__item-image-phone',
97
/* VALUES END */
), (
/* VALUES START */
5667,
179,
'_types__wrapper_2_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5668,
179,
'types__wrapper_2_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5669,
179,
'_types__wrapper_2_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5670,
179,
'types__wrapper_2_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5671,
179,
'_types__wrapper_2_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5672,
179,
'types__wrapper_2_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5673,
179,
'_types__wrapper_2_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5674,
179,
'types__wrapper_3_types__item-image',
98
/* VALUES END */
), (
/* VALUES START */
5675,
179,
'_types__wrapper_3_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5676,
179,
'types__wrapper_3_types__item-image-phone',
99
/* VALUES END */
), (
/* VALUES START */
5677,
179,
'_types__wrapper_3_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5678,
179,
'types__wrapper_3_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5679,
179,
'_types__wrapper_3_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5680,
179,
'types__wrapper_3_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5681,
179,
'_types__wrapper_3_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5682,
179,
'types__wrapper_3_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5683,
179,
'_types__wrapper_3_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5684,
179,
'types__wrapper_4_types__item-image',
100
/* VALUES END */
), (
/* VALUES START */
5685,
179,
'_types__wrapper_4_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5686,
179,
'types__wrapper_4_types__item-image-phone',
101
/* VALUES END */
), (
/* VALUES START */
5687,
179,
'_types__wrapper_4_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5688,
179,
'types__wrapper_4_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5689,
179,
'_types__wrapper_4_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5690,
179,
'types__wrapper_4_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5691,
179,
'_types__wrapper_4_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5692,
179,
'types__wrapper_4_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5693,
179,
'_types__wrapper_4_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5694,
179,
'types__wrapper_5_types__item-image',
102
/* VALUES END */
), (
/* VALUES START */
5695,
179,
'_types__wrapper_5_types__item-image',
'field_619e755da10ff'
/* VALUES END */
), (
/* VALUES START */
5696,
179,
'types__wrapper_5_types__item-image-phone',
103
/* VALUES END */
), (
/* VALUES START */
5697,
179,
'_types__wrapper_5_types__item-image-phone',
'field_619e758ea1100'
/* VALUES END */
), (
/* VALUES START */
5698,
179,
'types__wrapper_5_types__item-link-text',
'BUY NOW'
/* VALUES END */
), (
/* VALUES START */
5699,
179,
'_types__wrapper_5_types__item-link-text',
'field_619e75d9a1101'
/* VALUES END */
), (
/* VALUES START */
5700,
179,
'types__wrapper_5_types__item-link',
'#'
/* VALUES END */
), (
/* VALUES START */
5701,
179,
'_types__wrapper_5_types__item-link',
'field_619e760da1102'
/* VALUES END */
), (
/* VALUES START */
5702,
179,
'types__wrapper_5_types__item-link-color',
'#ffea30'
/* VALUES END */
), (
/* VALUES START */
5703,
179,
'_types__wrapper_5_types__item-link-color',
'field_619e761da1103'
/* VALUES END */
), (
/* VALUES START */
5704,
179,
'about__title',
'WHAT IS AN NFT MOON TOKEN?'
/* VALUES END */
), (
/* VALUES START */
5705,
179,
'_about__title',
'field_619e7a488320e'
/* VALUES END */
), (
/* VALUES START */
5706,
179,
'about__wrapper_about__info-title-1',
'NFT'
/* VALUES END */
), (
/* VALUES START */
5707,
179,
'_about__wrapper_about__info-title-1',
'field_619e7abf83210'
/* VALUES END */
), (
/* VALUES START */
5708,
179,
'about__wrapper_about__info-title-2',
'<span>MOON</span>\r\nTOKEN'
/* VALUES END */
), (
/* VALUES START */
5709,
179,
'_about__wrapper_about__info-title-2',
'field_619e7ad583211'
/* VALUES END */
), (
/* VALUES START */
5710,
179,
'about__wrapper_about__info-text',
'NFT stands for a Non-Fungible Token - the type of a specific blockchain-based cryptographic digital unit introduced in late 2017. It\'s peculiarity lies in its definition: each token is unique and indivisible and cannot be exchanged or replaced by the other unit of this type.'
/* VALUES END */
), (
/* VALUES START */
5711,
179,
'_about__wrapper_about__info-text',
'field_619e7ae983212'
/* VALUES END */
), (
/* VALUES START */
5712,
179,
'about__wrapper_about__image',
112
/* VALUES END */
), (
/* VALUES START */
5713,
179,
'_about__wrapper_about__image',
'field_619e7b1783213'
/* VALUES END */
), (
/* VALUES START */
5714,
179,
'about__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5715,
179,
'_about__wrapper',
'field_619e7aac8320f'
/* VALUES END */
), (
/* VALUES START */
5716,
179,
'ownership__title',
'OWNERSHIP AND UNIQUENESS'
/* VALUES END */
), (
/* VALUES START */
5717,
179,
'_ownership__title',
'field_619e7d91af21f'
/* VALUES END */
), (
/* VALUES START */
5718,
179,
'ownership__wrapper_ownership__info-title',
'EACH LAND IS AN NFT CERTIFICATE'
/* VALUES END */
), (
/* VALUES START */
5719,
179,
'_ownership__wrapper_ownership__info-title',
'field_619e7dc7af221'
/* VALUES END */
), (
/* VALUES START */
5720,
179,
'ownership__wrapper_ownership__info-description',
'There will be a total of 5889 NFT Moon Standart certificates in the Moon Metaverse. Each certificate authenticates the ownership of a virtual land plot in the Metaverse. After the purchase, you will receive a certificate and a 2D-3D map with a panorama of your land plot. After the launch of the Metaverse you will be able to: build houses, cities, countries, create NFT items, rent and sell land and everything else that belongs to you. You and the other owners will create an economy and earn real money. You will become a member of the closed NFT Moon club. After the launch of the game, you will be able to see how all the features of this certificate work.'
/* VALUES END */
), (
/* VALUES START */
5721,
179,
'_ownership__wrapper_ownership__info-description',
'field_619e7e3baf222'
/* VALUES END */
), (
/* VALUES START */
5722,
179,
'ownership__wrapper_ownership__image',
120
/* VALUES END */
), (
/* VALUES START */
5723,
179,
'_ownership__wrapper_ownership__image',
'field_619e7e69af223'
/* VALUES END */
), (
/* VALUES START */
5724,
179,
'ownership__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5725,
179,
'_ownership__wrapper',
'field_619e7db6af220'
/* VALUES END */
), (
/* VALUES START */
5726,
179,
'exchange__title',
'NFT TOKEN EXCHANGE'
/* VALUES END */
), (
/* VALUES START */
5727,
179,
'_exchange__title',
'field_619e80543e278'
/* VALUES END */
), (
/* VALUES START */
5728,
179,
'exchange__wrapper_exchange__info-title',
'AN EASY WAY TO BUY OR SELL'
/* VALUES END */
), (
/* VALUES START */
5729,
179,
'_exchange__wrapper_exchange__info-title',
'field_619e80d73e27a'
/* VALUES END */
), (
/* VALUES START */
5730,
179,
'exchange__wrapper_exchange__info-text',
'Your NFT belongs only to you. You can easily resell it on any NFT exchange. There is only one version of each NFT Moon certificate (land plot) and none of them is the same. It is a really good investment to make.'
/* VALUES END */
), (
/* VALUES START */
5731,
179,
'_exchange__wrapper_exchange__info-text',
'field_619e80ed3e27b'
/* VALUES END */
), (
/* VALUES START */
5732,
179,
'exchange__wrapper_exchange__image',
128
/* VALUES END */
), (
/* VALUES START */
5733,
179,
'_exchange__wrapper_exchange__image',
'field_619e80ff3e27c'
/* VALUES END */
), (
/* VALUES START */
5734,
179,
'exchange__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5735,
179,
'_exchange__wrapper',
'field_619e80ac3e279'
/* VALUES END */
), (
/* VALUES START */
5736,
179,
'links__list-1_links__list-text-1',
'RENT'
/* VALUES END */
), (
/* VALUES START */
5737,
179,
'_links__list-1_links__list-text-1',
'field_619f5dcb9d687'
/* VALUES END */
), (
/* VALUES START */
5738,
179,
'links__list-1_links__list-link-1',
'#'
/* VALUES END */
), (
/* VALUES START */
5739,
179,
'_links__list-1_links__list-link-1',
'field_619f5e619d68d'
/* VALUES END */
), (
/* VALUES START */
5740,
179,
'links__list-1_links__list-text-2',
'LAND'
/* VALUES END */
), (
/* VALUES START */
5741,
179,
'_links__list-1_links__list-text-2',
'field_619f5e1b9d688'
/* VALUES END */
), (
/* VALUES START */
5742,
179,
'links__list-1_links__list-link-2',
'#'
/* VALUES END */
), (
/* VALUES START */
5743,
179,
'_links__list-1_links__list-link-2',
'field_619f5e829d68e'
/* VALUES END */
), (
/* VALUES START */
5744,
179,
'links__list-1_links__list-text-3',
'TOKENS'
/* VALUES END */
), (
/* VALUES START */
5745,
179,
'_links__list-1_links__list-text-3',
'field_619f5e1e9d689'
/* VALUES END */
), (
/* VALUES START */
5746,
179,
'links__list-1_links__list-link-3',
'#'
/* VALUES END */
), (
/* VALUES START */
5747,
179,
'_links__list-1_links__list-link-3',
'field_619f5e849d68f'
/* VALUES END */
), (
/* VALUES START */
5748,
179,
'links__list-1_links__list-text-4',
'FARMING'
/* VALUES END */
), (
/* VALUES START */
5749,
179,
'_links__list-1_links__list-text-4',
'field_619f5e209d68a'
/* VALUES END */
), (
/* VALUES START */
5750,
179,
'links__list-1_links__list-link-4',
'#'
/* VALUES END */
), (
/* VALUES START */
5751,
179,
'_links__list-1_links__list-link-4',
'field_619f5e859d690'
/* VALUES END */
), (
/* VALUES START */
5752,
179,
'links__list-1_links__list-text-5',
'STACKING'
/* VALUES END */
), (
/* VALUES START */
5753,
179,
'_links__list-1_links__list-text-5',
'field_619f5e229d68b'
/* VALUES END */
), (
/* VALUES START */
5754,
179,
'links__list-1_links__list-link-5',
'#'
/* VALUES END */
), (
/* VALUES START */
5755,
179,
'_links__list-1_links__list-link-5',
'field_619f5e889d691'
/* VALUES END */
), (
/* VALUES START */
5756,
179,
'links__list-1_links__list-text-6',
'RESALE'
/* VALUES END */
), (
/* VALUES START */
5757,
179,
'_links__list-1_links__list-text-6',
'field_619f5e249d68c'
/* VALUES END */
), (
/* VALUES START */
5758,
179,
'links__list-1_links__list-link-6',
'#'
/* VALUES END */
), (
/* VALUES START */
5759,
179,
'_links__list-1_links__list-link-6',
'field_619f5e8a9d692'
/* VALUES END */
), (
/* VALUES START */
5760,
179,
'links__list-1',
''
/* VALUES END */
), (
/* VALUES START */
5761,
179,
'_links__list-1',
'field_619f5d969d686'
/* VALUES END */
), (
/* VALUES START */
5762,
179,
'links__list-2_links__list-text-7',
'DISTRIBUTION\r\nOF INCOME FROM\r\nTHE METAVERSE'
/* VALUES END */
), (
/* VALUES START */
5763,
179,
'_links__list-2_links__list-text-7',
'field_619f6018392fd'
/* VALUES END */
), (
/* VALUES START */
5764,
179,
'links__list-2_links__list-link-7',
'#'
/* VALUES END */
), (
/* VALUES START */
5765,
179,
'_links__list-2_links__list-link-7',
'field_619f6018392fe'
/* VALUES END */
), (
/* VALUES START */
5766,
179,
'links__list-2_links__list-text-8',
'DISTRIBUTION\r\nOF RARE NFTs'
/* VALUES END */
), (
/* VALUES START */
5767,
179,
'_links__list-2_links__list-text-8',
'field_619f6018392ff'
/* VALUES END */
), (
/* VALUES START */
5768,
179,
'links__list-2_links__list-link-8',
'#'
/* VALUES END */
), (
/* VALUES START */
5769,
179,
'_links__list-2_links__list-link-8',
'field_619f601839300'
/* VALUES END */
), (
/* VALUES START */
5770,
179,
'links__list-2_links__list-text-9',
'DIVIDE THE PLOT\r\nINTO PARTS'
/* VALUES END */
), (
/* VALUES START */
5771,
179,
'_links__list-2_links__list-text-9',
'field_619f601839301'
/* VALUES END */
), (
/* VALUES START */
5772,
179,
'links__list-2_links__list-link-9',
'#'
/* VALUES END */
), (
/* VALUES START */
5773,
179,
'_links__list-2_links__list-link-9',
'field_619f601839302'
/* VALUES END */
), (
/* VALUES START */
5774,
179,
'links__list-2_links__list-text-10',
'ACCESS TO MORE\r\nTHE NUMBER OF\r\nGAME ITEMS'
/* VALUES END */
), (
/* VALUES START */
5775,
179,
'_links__list-2_links__list-text-10',
'field_619f601839303'
/* VALUES END */
), (
/* VALUES START */
5776,
179,
'links__list-2_links__list-link-10',
'#'
/* VALUES END */
), (
/* VALUES START */
5777,
179,
'_links__list-2_links__list-link-10',
'field_619f601839304'
/* VALUES END */
), (
/* VALUES START */
5778,
179,
'links__list-2',
''
/* VALUES END */
), (
/* VALUES START */
5779,
179,
'_links__list-2',
'field_619f6018392fc'
/* VALUES END */
), (
/* VALUES START */
5780,
179,
'roadmap__title',
'NFT MOON PROJECT ROADMAP'
/* VALUES END */
), (
/* VALUES START */
5781,
179,
'_roadmap__title',
'field_619f628f424e2'
/* VALUES END */
), (
/* VALUES START */
5782,
179,
'roadmap__description',
'We are frequently being asked the following question: If you are selling plots of the metaverse, where is the metaverse (the game) itself? In order to answer all the existing and future questions, we created the roadmap of our project.'
/* VALUES END */
), (
/* VALUES START */
5783,
179,
'_roadmap__description',
'field_619f62a7424e3'
/* VALUES END */
), (
/* VALUES START */
5784,
179,
'roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'STAGE 1'
/* VALUES END */
), (
/* VALUES START */
5785,
179,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-title',
'field_619f6376424e6'
/* VALUES END */
), (
/* VALUES START */
5786,
179,
'roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
5787,
179,
'_roadmap__wrapper_roadmap__item_0_roadmap__item-text',
'field_619f63a3424e7'
/* VALUES END */
), (
/* VALUES START */
5788,
179,
'roadmap__wrapper_roadmap__item',
1
/* VALUES END */
), (
/* VALUES START */
5789,
179,
'_roadmap__wrapper_roadmap__item',
'field_619f6352424e5'
/* VALUES END */
), (
/* VALUES START */
5790,
179,
'roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'Release of the first NFT Moon'
/* VALUES END */
), (
/* VALUES START */
5791,
179,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-title',
'field_619f63dd424e9'
/* VALUES END */
), (
/* VALUES START */
5792,
179,
'roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'This is the stage in which the idea is formed! At this stage, the main task of the NFT Moon project is to attract the first owners of NFT Moon. Also issue the first 100 NFT Moon certificates and sell them.'
/* VALUES END */
), (
/* VALUES START */
5793,
179,
'_roadmap__wrapper_roadmap__box_0_roadmap__box-text',
'field_619f63fd424ea'
/* VALUES END */
), (
/* VALUES START */
5794,
179,
'roadmap__wrapper_roadmap__box',
1
/* VALUES END */
), (
/* VALUES START */
5795,
179,
'_roadmap__wrapper_roadmap__box',
'field_619f63ba424e8'
/* VALUES END */
), (
/* VALUES START */
5796,
179,
'roadmap__wrapper',
''
/* VALUES END */
), (
/* VALUES START */
5797,
179,
'_roadmap__wrapper',
'field_619f6328424e4'
/* VALUES END */
), (
/* VALUES START */
5798,
179,
'burger',
171
/* VALUES END */
), (
/* VALUES START */
5799,
179,
'_burger',
'field_61a0b1abf39fa'
/* VALUES END */
), (
/* VALUES START */
5800,
179,
'hero__box_hero__box-color',
'#92f8ff'
/* VALUES END */
), (
/* VALUES START */
5801,
179,
'_hero__box_hero__box-color',
'field_61a0d0d88226e'
/* VALUES END */
), (
/* VALUES START */
5802,
9,
'_wp_page_template',
'page-main.php'
/* VALUES END */
);
/* QUERY END */

