/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_usermeta`; */
/* PRE_TABLE_NAME: `1638034363_wp_usermeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1638034363_wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1638034363_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
1,
'nickname',
'moon-admin'
/* VALUES END */
), (
/* VALUES START */
2,
1,
'first_name',
''
/* VALUES END */
), (
/* VALUES START */
3,
1,
'last_name',
''
/* VALUES END */
), (
/* VALUES START */
4,
1,
'description',
''
/* VALUES END */
), (
/* VALUES START */
5,
1,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
6,
1,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
7,
1,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
8,
1,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
9,
1,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
10,
1,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
11,
1,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
12,
1,
'wp_capabilities',
'a:1:{s:13:\"administrator\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
13,
1,
'wp_user_level',
10
/* VALUES END */
), (
/* VALUES START */
14,
1,
'dismissed_wp_pointers',
'theme_editor_notice,plugin_editor_notice'
/* VALUES END */
), (
/* VALUES START */
15,
1,
'show_welcome_panel',
1
/* VALUES END */
), (
/* VALUES START */
16,
1,
'session_tokens',
'a:4:{s:64:\"bb4ca35dc88f00906e59635251121c04cf5f9537def1535e71bd80eb8f5ad163\";a:4:{s:10:\"expiration\";i:1638095399;s:2:\"ip\";s:13:\"185.130.54.25\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36\";s:5:\"login\";i:1637922599;}s:64:\"d3884aaf79c1b8b13e9e6402e4b4f18f15d1689d17b773cf07720f8b48d3a44e\";a:4:{s:10:\"expiration\";i:1638100898;s:2:\"ip\";s:13:\"88.155.67.106\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36\";s:5:\"login\";i:1637928098;}s:64:\"42abf0354063db4184ea07a74817aba140e6a9ecc9b00500ffcb5f28c89f26dd\";a:4:{s:10:\"expiration\";i:1639144059;s:2:\"ip\";s:14:\"91.201.244.129\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36\";s:5:\"login\";i:1637934459;}s:64:\"ed4f11907050c96dd69751fa5818a4af34ac49e33d7e6ff208482c022f064438\";a:4:{s:10:\"expiration\";i:1639236191;s:2:\"ip\";s:13:\"91.201.244.51\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36\";s:5:\"login\";i:1638026591;}}'
/* VALUES END */
), (
/* VALUES START */
17,
1,
'wp_dashboard_quick_press_last_post_id',
4
/* VALUES END */
), (
/* VALUES START */
18,
1,
'community-events-location',
'a:1:{s:2:\"ip\";s:12:\"91.201.244.0\";}'
/* VALUES END */
), (
/* VALUES START */
19,
1,
'wp_user-settings',
'libraryContent=browse&editor=tinymce&hidetb=1&editor_plain_text_paste_warning=1'
/* VALUES END */
), (
/* VALUES START */
20,
1,
'wp_user-settings-time',
1637923667
/* VALUES END */
), (
/* VALUES START */
21,
1,
'meta-box-order_page',
'a:4:{s:6:\"normal\";s:23:\"acf-group_619e379e66657\";s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:0:\"\";s:8:\"advanced\";s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
22,
1,
'closedpostboxes_page',
'a:1:{i:0;s:12:\"revisionsdiv\";}'
/* VALUES END */
), (
/* VALUES START */
23,
1,
'metaboxhidden_page',
'a:0:{}'
/* VALUES END */
);
/* QUERY END */

